let isRecording = false;
let activeSessionId = null;
let flushTimer = null;
let eventQueue = [];
let lastPointerMoveAt = 0;
let lastPointerPoint = null;

const MAX_TEXT_LENGTH = 160;

function now() {
  return Date.now();
}

function truncate(value) {
  if (!value) {
    return "";
  }

  return value.length > MAX_TEXT_LENGTH ? `${value.slice(0, MAX_TEXT_LENGTH)}…` : value;
}

function getViewport() {
  return {
    width: window.innerWidth,
    height: window.innerHeight,
    devicePixelRatio: window.devicePixelRatio || 1,
    scrollX: window.scrollX,
    scrollY: window.scrollY
  };
}

function cssEscape(value) {
  if (!value) {
    return "";
  }

  return CSS.escape(String(value));
}

function buildCssPath(element) {
  if (!element || element.nodeType !== Node.ELEMENT_NODE) {
    return null;
  }

  const parts = [];
  let current = element;

  while (current && current.nodeType === Node.ELEMENT_NODE && parts.length < 6) {
    let selector = current.tagName.toLowerCase();

    if (current.id) {
      selector += `#${cssEscape(current.id)}`;
      parts.unshift(selector);
      break;
    }

    if (current.classList.length) {
      selector += `.${Array.from(current.classList).slice(0, 2).map(cssEscape).join(".")}`;
    }

    const parent = current.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children).filter((child) => child.tagName === current.tagName);
      if (siblings.length > 1) {
        selector += `:nth-of-type(${siblings.indexOf(current) + 1})`;
      }
    }

    parts.unshift(selector);
    current = current.parentElement;
  }

  return parts.join(" > ");
}

function buildTargetDescriptor(target) {
  const element = target instanceof Element ? target : null;

  if (!element) {
    return null;
  }

  const rect = element.getBoundingClientRect();
  const text = truncate((element.innerText || element.textContent || "").trim().replace(/\s+/g, " "));
  const selectors = [];

  if (element.id) {
    selectors.push(`#${cssEscape(element.id)}`);
  }

  const testId = element.getAttribute("data-testid") || element.getAttribute("data-test-id");
  if (testId) {
    selectors.push(`[data-testid="${cssEscape(testId)}"]`);
  }

  const name = element.getAttribute("name");
  if (name) {
    selectors.push(`${element.tagName.toLowerCase()}[name="${cssEscape(name)}"]`);
  }

  const ariaLabel = element.getAttribute("aria-label");
  if (ariaLabel) {
    selectors.push(`${element.tagName.toLowerCase()}[aria-label="${cssEscape(ariaLabel)}"]`);
  }

  const placeholder = element.getAttribute("placeholder");
  if (placeholder) {
    selectors.push(`${element.tagName.toLowerCase()}[placeholder="${cssEscape(placeholder)}"]`);
  }

  const cssPath = buildCssPath(element);
  if (cssPath) {
    selectors.push(cssPath);
  }

  return {
    tagName: element.tagName.toLowerCase(),
    id: element.id || null,
    className: truncate(element.className || ""),
    name: name || null,
    type: element.getAttribute("type") || null,
    role: element.getAttribute("role") || null,
    ariaLabel: ariaLabel || null,
    placeholder: placeholder || null,
    text,
    href: element.getAttribute("href") || null,
    selectors,
    bounds: {
      left: rect.left,
      top: rect.top,
      width: rect.width,
      height: rect.height
    }
  };
}

function scheduleFlush() {
  if (!isRecording || flushTimer || !eventQueue.length) {
    return;
  }

  flushTimer = setTimeout(flushEvents, 250);
}

async function flushEvents() {
  if (!eventQueue.length) {
    flushTimer = null;
    return;
  }

  const events = eventQueue;
  eventQueue = [];
  flushTimer = null;

  try {
    await chrome.runtime.sendMessage({
      type: "RECORD_BATCH",
      sessionId: activeSessionId,
      events
    });
  } catch (error) {
    console.warn("Demo Guilds recorder flush failed", error);
    eventQueue = [...events, ...eventQueue];
  }
}

function enqueue(event) {
  if (!isRecording) {
    return;
  }

  eventQueue.push({
    at: now(),
    url: location.href,
    title: document.title,
    viewport: getViewport(),
    ...event
  });

  scheduleFlush();
}

function isSensitiveTarget(target) {
  const element = target instanceof HTMLInputElement ? target : null;
  if (!element) {
    return false;
  }

  return element.type === "password";
}

function normalizePointer(event) {
  return {
    clientX: event.clientX,
    clientY: event.clientY,
    pageX: event.pageX,
    pageY: event.pageY,
    normalizedX: Number((event.clientX / window.innerWidth).toFixed(4)),
    normalizedY: Number((event.clientY / window.innerHeight).toFixed(4)),
    button: event.button,
    buttons: event.buttons
  };
}

function handlePointerMove(event) {
  if (!isRecording) {
    return;
  }

  const movedEnough =
    !lastPointerPoint ||
    Math.abs(lastPointerPoint.x - event.clientX) > 2 ||
    Math.abs(lastPointerPoint.y - event.clientY) > 2;

  if (!movedEnough || now() - lastPointerMoveAt < 40) {
    return;
  }

  lastPointerMoveAt = now();
  lastPointerPoint = { x: event.clientX, y: event.clientY };

  enqueue({
    type: "POINTER_MOVE",
    ...normalizePointer(event),
    target: buildTargetDescriptor(event.target)
  });
}

function handlePointerDown(event) {
  enqueue({
    type: "POINTER_DOWN",
    ...normalizePointer(event),
    target: buildTargetDescriptor(event.target)
  });
}

function handlePointerUp(event) {
  enqueue({
    type: "POINTER_UP",
    ...normalizePointer(event),
    target: buildTargetDescriptor(event.target)
  });
}

function handleClick(event) {
  enqueue({
    type: "CLICK",
    ...normalizePointer(event),
    target: buildTargetDescriptor(event.target)
  });
}

function handleDoubleClick(event) {
  enqueue({
    type: "DOUBLE_CLICK",
    ...normalizePointer(event),
    target: buildTargetDescriptor(event.target)
  });
}

function handleWheel(event) {
  enqueue({
    type: "WHEEL",
    ...normalizePointer(event),
    deltaX: event.deltaX,
    deltaY: event.deltaY,
    target: buildTargetDescriptor(event.target)
  });
}

function handleScroll(event) {
  const target = event.target === document ? document.scrollingElement : event.target;
  const element = target instanceof Element ? target : document.scrollingElement;
  const descriptor = buildTargetDescriptor(element);

  enqueue({
    type: "SCROLL",
    target: descriptor,
    scrollTarget: element === document.scrollingElement ? "window" : "element",
    scrollTop: element ? element.scrollTop : window.scrollY,
    scrollLeft: element ? element.scrollLeft : window.scrollX,
    pageScrollX: window.scrollX,
    pageScrollY: window.scrollY
  });
}

function handleKeyDown(event) {
  enqueue({
    type: "KEY_DOWN",
    key: event.key,
    code: event.code,
    printable: event.key.length === 1 ? event.key : null,
    repeat: event.repeat,
    altKey: event.altKey,
    ctrlKey: event.ctrlKey,
    shiftKey: event.shiftKey,
    metaKey: event.metaKey,
    target: buildTargetDescriptor(event.target)
  });
}

function handleKeyUp(event) {
  enqueue({
    type: "KEY_UP",
    key: event.key,
    code: event.code,
    altKey: event.altKey,
    ctrlKey: event.ctrlKey,
    shiftKey: event.shiftKey,
    metaKey: event.metaKey,
    target: buildTargetDescriptor(event.target)
  });
}

function handleInput(event) {
  const target = event.target;
  const sensitive = isSensitiveTarget(target);
  const isEditable = target instanceof HTMLElement && target.isContentEditable;
  const value =
    sensitive
      ? null
      : typeof target?.value === "string"
        ? target.value
        : isEditable
          ? target.innerText || target.textContent || ""
          : null;

  enqueue({
    type: "INPUT",
    value,
    target: buildTargetDescriptor(target)
  });
}

function handleChange(event) {
  const target = event.target;
  const sensitive = isSensitiveTarget(target);

  enqueue({
    type: "CHANGE",
    value: sensitive ? null : typeof target?.value === "string" ? target.value : null,
    checked: typeof target?.checked === "boolean" ? target.checked : null,
    target: buildTargetDescriptor(target)
  });
}

function handleSelectionChange() {
  const selection = document.getSelection();
  if (!selection || selection.isCollapsed) {
    return;
  }

  enqueue({
    type: "SELECTION_CHANGE",
    text: truncate(String(selection).replace(/\s+/g, " ").trim())
  });
}

function announcePageReady() {
  enqueue({
    type: "PAGE_READY"
  });
}

function installHistoryBridge() {
  const script = document.createElement("script");
  script.textContent = `
    (() => {
      if (window.__dgHistoryBridgeInstalled) {
        return;
      }
      window.__dgHistoryBridgeInstalled = true;
      const notify = (type) => {
        window.postMessage({
          source: "demo-guilds-recorder",
          type,
          href: location.href,
          title: document.title
        }, "*");
      };
      const wrap = (key) => {
        const original = history[key];
        history[key] = function (...args) {
          const result = original.apply(this, args);
          notify(key);
          return result;
        };
      };
      wrap("pushState");
      wrap("replaceState");
      window.addEventListener("popstate", () => notify("popstate"));
      window.addEventListener("hashchange", () => notify("hashchange"));
    })();
  `;
  (document.documentElement || document.head).appendChild(script);
  script.remove();
}

window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.source !== "demo-guilds-recorder") {
    return;
  }

  enqueue({
    type: "URL_CHANGED",
    changeKind: event.data.type,
    url: event.data.href,
    title: event.data.title
  });
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.type !== "DG_RECORDER_STATE_CHANGED") {
    return;
  }

  isRecording = Boolean(message.isRecording);
  activeSessionId = message.sessionId || null;

  if (isRecording) {
    enqueue({
      type: "PAGE_CONTEXT",
      url: location.href
    });
  } else {
    flushEvents();
  }
});

async function bootstrap() {
  installHistoryBridge();

  try {
    const state = await chrome.runtime.sendMessage({ type: "GET_STATE" });
    isRecording = Boolean(state.isRecording);
    activeSessionId = state.currentSession?.id || null;
  } catch (error) {
    console.warn("Demo Guilds recorder could not read state", error);
  }

  document.addEventListener("pointermove", handlePointerMove, true);
  document.addEventListener("pointerdown", handlePointerDown, true);
  document.addEventListener("pointerup", handlePointerUp, true);
  document.addEventListener("click", handleClick, true);
  document.addEventListener("dblclick", handleDoubleClick, true);
  document.addEventListener("wheel", handleWheel, { capture: true, passive: true });
  document.addEventListener("scroll", handleScroll, true);
  document.addEventListener("keydown", handleKeyDown, true);
  document.addEventListener("keyup", handleKeyUp, true);
  document.addEventListener("input", handleInput, true);
  document.addEventListener("change", handleChange, true);
  document.addEventListener("selectionchange", handleSelectionChange, true);
  window.addEventListener("load", announcePageReady, { once: true });

  if (document.readyState === "complete") {
    announcePageReady();
  }
}

bootstrap();
