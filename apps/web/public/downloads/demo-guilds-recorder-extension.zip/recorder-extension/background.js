const CURRENT_SESSION_KEY = "dg.currentSession";
const SAVED_SESSIONS_KEY = "dg.savedSessions";

let activeSession = null;
let persistTimer = null;

async function getSavedSessions() {
  const stored = await chrome.storage.local.get(SAVED_SESSIONS_KEY);
  return stored[SAVED_SESSIONS_KEY] || {};
}

async function saveSavedSessions(sessions) {
  await chrome.storage.local.set({ [SAVED_SESSIONS_KEY]: sessions });
}

async function persistCurrentSession() {
  if (!activeSession) {
    await chrome.storage.local.remove(CURRENT_SESSION_KEY);
    return;
  }

  await chrome.storage.local.set({ [CURRENT_SESSION_KEY]: activeSession });
}

function queuePersist() {
  if (persistTimer) {
    return;
  }

  persistTimer = setTimeout(async () => {
    persistTimer = null;
    await persistCurrentSession();
  }, 500);
}

function summarizeSession(session) {
  return {
    id: session.id,
    name: session.name,
    startedAt: session.startedAt,
    endedAt: session.endedAt,
    eventCount: session.events.length,
    initialUrl: session.meta.initialUrl
  };
}

async function loadCurrentSession() {
  if (activeSession) {
    return activeSession;
  }

  const stored = await chrome.storage.local.get(CURRENT_SESSION_KEY);
  activeSession = stored[CURRENT_SESSION_KEY] || null;
  return activeSession;
}

function now() {
  return Date.now();
}

async function broadcastRecorderState() {
  const tabs = await chrome.tabs.query({});
  const payload = {
    type: "DG_RECORDER_STATE_CHANGED",
    isRecording: Boolean(activeSession),
    sessionId: activeSession?.id || null
  };

  await Promise.allSettled(
    tabs.map((tab) => {
      if (!tab.id || !tab.url?.startsWith("http")) {
        return Promise.resolve();
      }

      return chrome.tabs.sendMessage(tab.id, payload);
    })
  );
}

async function createSession(name = "") {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const id = `trace-${Date.now()}`;

  activeSession = {
    version: 1,
    id,
    name: name || `Session ${new Date().toLocaleString()}`,
    startedAt: now(),
    endedAt: null,
    meta: {
      extensionVersion: chrome.runtime.getManifest().version,
      userAgent: navigator.userAgent,
      initialUrl: tab?.url || null,
      initialTitle: tab?.title || null,
      sourceViewport: null
    },
    tabs: {},
    events: []
  };

  if (tab?.id) {
    activeSession.tabs[String(tab.id)] = {
      tabId: tab.id,
      url: tab.url,
      title: tab.title
    };
  }

  activeSession.events.push({
    type: "SESSION_STARTED",
    at: now(),
    url: tab?.url || null,
    title: tab?.title || null
  });

  await persistCurrentSession();
  await broadcastRecorderState();
  return activeSession;
}

async function finalizeSession() {
  if (!activeSession) {
    return null;
  }

  activeSession.endedAt = now();
  activeSession.events.push({
    type: "SESSION_STOPPED",
    at: activeSession.endedAt
  });

  const completed = activeSession;
  const sessions = await getSavedSessions();
  sessions[completed.id] = completed;
  await saveSavedSessions(sessions);

  activeSession = null;
  await chrome.storage.local.remove(CURRENT_SESSION_KEY);
  await broadcastRecorderState();
  return completed;
}

function appendEvent(event, sender = null) {
  if (!activeSession) {
    return;
  }

  const tabId = sender?.tab?.id;
  const eventWithContext = {
    at: event.at || now(),
    ...event
  };

  if (tabId) {
    eventWithContext.tabId = tabId;

    activeSession.tabs[String(tabId)] = {
      tabId,
      url: sender.tab?.url || event.url || null,
      title: sender.tab?.title || null
    };
  }

  if (!activeSession.meta.sourceViewport && event.viewport) {
    activeSession.meta.sourceViewport = event.viewport;
  }

  activeSession.events.push(eventWithContext);
  queuePersist();
}

async function exportSession(sessionId) {
  const sessions = await getSavedSessions();
  const session = sessions[sessionId];

  if (!session) {
    throw new Error("Session not found.");
  }

  const blob = new Blob([JSON.stringify(session, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);

  try {
    await chrome.downloads.download({
      url,
      filename: `demo-guilds/${session.id}.json`,
      saveAs: true
    });
  } finally {
    URL.revokeObjectURL(url);
  }
}

async function pushToPlayer(sessionId) {
  const sessions = await getSavedSessions();
  const session = sessions[sessionId];

  if (!session) {
    return { ok: false, error: "Session not found." };
  }

  try {
    const response = await fetch("http://127.0.0.1:4312/api/import-trace", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(session)
    });

    if (!response.ok) {
      return {
        ok: false,
        error: `Local player returned ${response.status}.`
      };
    }

    return { ok: true };
  } catch (error) {
    return {
      ok: false,
      error: `Could not reach local player at http://127.0.0.1:4312 (${error.message}).`
    };
  }
}

chrome.runtime.onInstalled.addListener(loadCurrentSession);
chrome.runtime.onStartup.addListener(loadCurrentSession);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const run = async () => {
    await loadCurrentSession();

    switch (message.type) {
      case "GET_STATE": {
        const sessions = Object.values(await getSavedSessions())
          .sort((a, b) => b.startedAt - a.startedAt)
          .map(summarizeSession);

        return {
          isRecording: Boolean(activeSession),
          currentSession: activeSession ? summarizeSession(activeSession) : null,
          sessions
        };
      }
      case "START_RECORDING": {
        if (activeSession) {
          return { ok: false, error: "A recording session is already active." };
        }

        await createSession(message.sessionName);
        return { ok: true };
      }
      case "STOP_RECORDING": {
        if (!activeSession) {
          return { ok: false, error: "There is no active recording session." };
        }

        await finalizeSession();
        return { ok: true };
      }
      case "RECORD_BATCH": {
        if (!activeSession || !Array.isArray(message.events)) {
          return { ok: false };
        }

        for (const event of message.events) {
          appendEvent(event, sender);
        }

        return { ok: true };
      }
      case "EXPORT_SESSION": {
        await exportSession(message.sessionId);
        return { ok: true };
      }
      case "PUSH_TO_PLAYER": {
        return pushToPlayer(message.sessionId);
      }
      default:
        return { ok: false, error: "Unknown message." };
    }
  };

  run().then(sendResponse).catch((error) => {
    sendResponse({
      ok: false,
      error: error.message
    });
  });

  return true;
});

chrome.tabs.onActivated.addListener(async ({ tabId, windowId }) => {
  await loadCurrentSession();

  if (!activeSession) {
    return;
  }

  const tab = await chrome.tabs.get(tabId);
  appendEvent({
    type: "TAB_ACTIVATED",
    at: now(),
    tabId,
    windowId,
    url: tab.url || null,
    title: tab.title || null
  });
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  await loadCurrentSession();

  if (!activeSession) {
    return;
  }

  if (changeInfo.url) {
    appendEvent({
      type: "TAB_URL_UPDATED",
      at: now(),
      tabId,
      url: changeInfo.url,
      title: tab.title || null
    });
  }
});

chrome.webNavigation.onCommitted.addListener(async (details) => {
  await loadCurrentSession();

  if (!activeSession || details.frameId !== 0) {
    return;
  }

  appendEvent({
    type: "NAVIGATION_COMMITTED",
    at: now(),
    tabId: details.tabId,
    url: details.url,
    transitionType: details.transitionType,
    transitionQualifiers: details.transitionQualifiers
  });
});
