const statusEl = document.getElementById("status");
const sessionNameEl = document.getElementById("sessionName");
const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const refreshBtn = document.getElementById("refreshBtn");
const sessionListEl = document.getElementById("sessionList");
const sessionTemplate = document.getElementById("sessionTemplate");

async function sendMessage(type, payload = {}) {
  return chrome.runtime.sendMessage({ type, ...payload });
}

function formatDate(value) {
  return new Date(value).toLocaleString();
}

function setStatus(message) {
  statusEl.textContent = message;
}

function renderSessions(sessions = []) {
  sessionListEl.innerHTML = "";

  if (!sessions.length) {
    sessionListEl.innerHTML = `<p class="subtle">No sessions recorded yet.</p>`;
    return;
  }

  for (const session of sessions) {
    const fragment = sessionTemplate.content.cloneNode(true);
    const root = fragment.querySelector(".session-card");
    fragment.querySelector(".session-title").textContent = session.name || session.id;
    fragment.querySelector(".session-meta").textContent =
      `${session.eventCount} events • ${formatDate(session.startedAt)} • ${session.initialUrl || "No URL captured"}`;

    root.querySelector('[data-action="download"]').addEventListener("click", async () => {
      setStatus("Preparing download…");
      await sendMessage("EXPORT_SESSION", { sessionId: session.id });
      setStatus("Trace downloaded.");
    });

    root.querySelector('[data-action="push"]').addEventListener("click", async () => {
      setStatus("Sending trace to local player…");
      const result = await sendMessage("PUSH_TO_PLAYER", { sessionId: session.id });
      if (!result.ok) {
        setStatus(result.error || "Could not send trace to local player.");
        return;
      }

      setStatus("Trace sent to local player.");
    });

    sessionListEl.appendChild(fragment);
  }
}

async function refreshState() {
  const response = await sendMessage("GET_STATE");
  const { isRecording, currentSession, sessions } = response;

  startBtn.disabled = Boolean(isRecording);
  stopBtn.disabled = !isRecording;

  if (isRecording && currentSession) {
    setStatus(`Recording now: ${currentSession.name || currentSession.id}`);
  } else {
    setStatus("Recorder is idle.");
  }

  renderSessions(sessions);
}

startBtn.addEventListener("click", async () => {
  const sessionName = sessionNameEl.value.trim();
  const response = await sendMessage("START_RECORDING", { sessionName });

  if (!response.ok) {
    setStatus(response.error || "Could not start recording.");
    return;
  }

  await refreshState();
});

stopBtn.addEventListener("click", async () => {
  const response = await sendMessage("STOP_RECORDING");

  if (!response.ok) {
    setStatus(response.error || "Could not stop recording.");
    return;
  }

  await refreshState();
});

refreshBtn.addEventListener("click", refreshState);

refreshState();
