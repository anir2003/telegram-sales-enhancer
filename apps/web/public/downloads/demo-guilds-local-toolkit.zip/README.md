# Demo Guilds Automation

Local MVP for recording browser demo flows and replaying them into videos.

## What is included

- A Chrome extension in `recorder-extension/` that records:
  - mouse movement and clicks
  - typing
  - page and container scrolling
  - URL changes
  - tab activation events
- A local player in `player/` that:
  - imports traces from the extension
  - previews the trace motion in a browser UI
  - replays the trace with Puppeteer
  - renders one video per input link or CSV row
  - names videos from the company/name column when provided
  - writes videos to a selected local output folder
  - can render two videos at the same time on the local machine
  - optionally merges audio with `ffmpeg`

## Local setup

1. Install dependencies:

```bash
npm install
```

2. Start the local player:

```bash
npm run player
```

3. Open Chrome and load the extension:
   - Go to `chrome://extensions`
   - Enable Developer mode
   - Click `Load unpacked`
   - Select `/Users/anir/Downloads/Demo Guilds automation/recorder-extension`

4. Record a template:
   - Open the target website
   - Click the extension icon
   - Press `Start Recording`
   - Perform the demo
   - Press `Stop Recording`
   - Use `Download JSON` or `Send To Player`

5. Render videos:
   - Open [http://127.0.0.1:4312](http://127.0.0.1:4312)
   - Select a trace in `Recordings`
   - Open `Render Batch`
   - Paste one or more links, or upload a CSV with `Name`/`Company` and `Link`/`URL` columns
   - Click `Choose Folder` to select where MP4s should be exported
   - Set `Parallel Videos` to `2` if you want two local Chromium renders at once
   - Click `Render Batch`
   - Use `Jobs & Logs` to pause, resume, cancel, or inspect a batch

## Notes

- This MVP records and replays the website content area. It does not capture Chrome's visible tab strip in the exported video.
- Tab changes are still recorded semantically and replayed as page navigation steps.
- Output files are written to `player/data/outputs/` unless you set another absolute export folder.
- CSV rows use the name/company column for the MP4 filename. If a filename already exists, the renderer appends a numeric suffix.
- Large batches are resumable at job boundaries. If the local player restarts while a batch is active, the job is recovered as paused so it does not keep rendering unexpectedly.
- Imported traces are stored in `player/data/traces/`.
- Job logs are stored in `player/data/jobs/`.

## Helpful commands

```bash
npm run player
npm run render -- --trace player/data/traces/YOUR_TRACE.json --links https://example.com/demo/one,https://example.com/demo/two
npm run check
```
