const state = {
  traces: [],
  jobs: [],
  selectedTraceId: null,
  selectedTrace: null,
  previewRequestId: null,
  previewProgress: 0,
  previewStartedAt: 0,
  previewBaseProgress: 0,
  isPreviewPlaying: false,
  theme: localStorage.getItem("dg-player-theme") || "dark"
};

const traceListEl = document.getElementById("traceList");
const traceDetailEl = document.getElementById("traceDetail");
const traceEmptyEl = document.getElementById("traceEmpty");
const detailTitleEl = document.getElementById("detailTitle");
const detailMetaEl = document.getElementById("detailMeta");
const eventListEl = document.getElementById("eventList");
const mockViewportEl = document.getElementById("mockViewport");
const mockCursorEl = document.getElementById("mockCursor");
const keystrokeOverlayEl = document.getElementById("keystrokeOverlay");
const previewStatusEl = document.getElementById("previewStatus");
const keystrokeChipsEl = document.getElementById("keystrokeChips");
const clickCountEl = document.getElementById("clickCount");
const keystrokeCountEl = document.getElementById("keystrokeCount");
const scrollCountEl = document.getElementById("scrollCount");
const navigationCountEl = document.getElementById("navigationCount");
const timelineRangeEl = document.getElementById("timelineRange");
const timelineLabelEl = document.getElementById("timelineLabel");
const timelineHintEl = document.getElementById("timelineHint");
const importFormEl = document.getElementById("importForm");
const importStatusEl = document.getElementById("importStatus");
const renderFormEl = document.getElementById("renderForm");
const renderStatusEl = document.getElementById("renderStatus");
const jobListEl = document.getElementById("jobList");
const playPausePreviewBtn = document.getElementById("playPausePreview");
const resetPreviewBtn = document.getElementById("resetPreview");
const themeToggleBtn = document.getElementById("themeToggle");

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function fmtDate(value) {
  return new Date(value).toLocaleString();
}

function fmtDuration(ms) {
  return `${(ms / 1000).toFixed(1)}s`;
}

function fetchJson(url, options = {}) {
  return fetch(url, options).then(async (response) => {
    const body = await response.json();
    if (!response.ok) {
      throw new Error(body.error || `Request failed (${response.status})`);
    }
    return body;
  });
}

function applyTheme() {
  document.documentElement.dataset.theme = state.theme;
  themeToggleBtn.textContent = state.theme === "dark" ? "Light Mode" : "Dark Mode";
  localStorage.setItem("dg-player-theme", state.theme);
}

function traceDuration(trace) {
  if (!trace?.events?.length) {
    return 0;
  }
  return Math.max(1, trace.events[trace.events.length - 1].at - trace.events[0].at);
}

function eventPoint(event, viewport) {
  const width = viewport.width || 1440;
  const height = viewport.height || 900;
  const x = typeof event.normalizedX === "number" ? event.normalizedX * width : event.clientX || 0;
  const y = typeof event.normalizedY === "number" ? event.normalizedY * height : event.clientY || 0;
  return { x, y };
}

function formatEventLabel(event) {
  switch (event.type) {
    case "CLICK":
      return `Clicked ${event.target?.text || event.target?.tagName || "element"}`;
    case "DOUBLE_CLICK":
      return `Double clicked ${event.target?.text || event.target?.tagName || "element"}`;
    case "SCROLL":
      return `Scrolled to ${event.pageScrollY || event.scrollTop || 0}px`;
    case "INPUT":
      return `Typed "${event.value || ""}"`;
    case "KEY_DOWN":
      return `Pressed ${event.key}`;
    case "TAB_ACTIVATED":
      return `Switched tab`;
    case "URL_CHANGED":
    case "NAVIGATION_COMMITTED":
      return `Navigated`;
    default:
      return event.type.replaceAll("_", " ");
  }
}

function summarizeTraceActivity(trace) {
  const counts = {
    clicks: 0,
    keystrokes: 0,
    scrolls: 0,
    navigations: 0
  };

  for (const event of trace.events) {
    if (event.type === "CLICK" || event.type === "DOUBLE_CLICK") {
      counts.clicks += 1;
    }
    if (event.type === "KEY_DOWN") {
      counts.keystrokes += 1;
    }
    if (event.type === "SCROLL" || event.type === "WHEEL") {
      counts.scrolls += 1;
    }
    if (event.type === "URL_CHANGED" || event.type === "NAVIGATION_COMMITTED" || event.type === "TAB_ACTIVATED") {
      counts.navigations += 1;
    }
  }

  return counts;
}

function collectKeystrokes(trace) {
  return trace.events
    .filter((event) => event.type === "KEY_DOWN")
    .map((event) => {
      if (event.printable) {
        return event.printable;
      }
      return event.key;
    })
    .filter(Boolean)
    .slice(-24);
}

function renderTraceList() {
  traceListEl.innerHTML = "";

  if (!state.traces.length) {
    traceListEl.innerHTML = `<p class="empty-state">No traces imported yet.</p>`;
    return;
  }

  for (const trace of state.traces) {
    const article = document.createElement("article");
    article.className = `trace-item ${trace.id === state.selectedTraceId ? "is-selected" : ""}`;
    article.innerHTML = `
      <div class="trace-item-top">
        <div>
          <h3>${escapeHtml(trace.name)}</h3>
          <p>${trace.eventCount} events</p>
        </div>
        <span class="badge">${fmtDuration(trace.durationMs)}</span>
      </div>
      <p class="trace-url">${escapeHtml(trace.initialUrl || "No URL recorded")}</p>
    `;

    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "Open Trace";
    button.addEventListener("click", () => loadTrace(trace.id));
    article.appendChild(button);
    traceListEl.appendChild(article);
  }
}

function renderEventList(trace) {
  const importantEvents = trace.events.filter((event) =>
    ["CLICK", "DOUBLE_CLICK", "SCROLL", "INPUT", "KEY_DOWN", "TAB_ACTIVATED", "URL_CHANGED", "NAVIGATION_COMMITTED"].includes(event.type)
  );

  if (!importantEvents.length) {
    eventListEl.innerHTML = `<p class="empty-state">No previewable activity captured.</p>`;
    return;
  }

  eventListEl.innerHTML = importantEvents
    .slice(0, 60)
    .map(
      (event) => `
        <article class="event-item">
          <div class="event-item-top">
            <strong>${escapeHtml(event.type.replaceAll("_", " "))}</strong>
            <span>${fmtDate(event.at)}</span>
          </div>
          <p>${escapeHtml(formatEventLabel(event))}</p>
          <p class="trace-url">${escapeHtml(event.url || event.target?.text || "")}</p>
        </article>
      `
    )
    .join("");
}

function renderKeystrokeChips(trace) {
  const keys = collectKeystrokes(trace);
  if (!keys.length) {
    keystrokeChipsEl.innerHTML = `<span class="empty-pill">No keystrokes captured yet</span>`;
    return;
  }

  keystrokeChipsEl.innerHTML = keys.map((key) => `<span class="chip">${escapeHtml(key)}</span>`).join("");
}

function resetPreviewUi() {
  mockCursorEl.style.transform = "translate(-9999px, -9999px)";
  keystrokeOverlayEl.classList.add("hidden");
  keystrokeOverlayEl.textContent = "";
  previewStatusEl.textContent = "Ready to preview";
}

function updatePreviewButtons() {
  playPausePreviewBtn.textContent = state.isPreviewPlaying ? "Pause" : "Play";
}

function drawPreviewFrame(progress) {
  const trace = state.selectedTrace;
  if (!trace?.events?.length) {
    resetPreviewUi();
    return;
  }

  const viewport = trace.meta.sourceViewport || { width: 1440, height: 900 };
  const width = mockViewportEl.clientWidth;
  const height = mockViewportEl.clientHeight;
  const startedAt = trace.events[0].at;
  const finishedAt = trace.events[trace.events.length - 1].at;
  const elapsed = startedAt + (finishedAt - startedAt) * progress;

  const eligible = trace.events.filter((event) => event.at <= elapsed);
  const lastPointEvent = [...eligible].reverse().find((event) => "normalizedX" in event || "clientX" in event);
  const lastSignalEvent = [...eligible].reverse().find((event) =>
    ["CLICK", "DOUBLE_CLICK", "SCROLL", "INPUT", "KEY_DOWN", "TAB_ACTIVATED", "URL_CHANGED", "NAVIGATION_COMMITTED"].includes(event.type)
  );

  if (lastPointEvent) {
    const point = eventPoint(lastPointEvent, viewport);
    const x = (point.x / viewport.width) * width;
    const y = (point.y / viewport.height) * height;
    mockCursorEl.style.transform = `translate(${x}px, ${y}px)`;
  }

  if (lastSignalEvent) {
    previewStatusEl.textContent = formatEventLabel(lastSignalEvent);

    if (lastSignalEvent.type === "KEY_DOWN") {
      keystrokeOverlayEl.textContent = lastSignalEvent.printable || lastSignalEvent.key;
      keystrokeOverlayEl.classList.remove("hidden");
    } else if (lastSignalEvent.type === "INPUT" && lastSignalEvent.value) {
      keystrokeOverlayEl.textContent = lastSignalEvent.value.slice(-20);
      keystrokeOverlayEl.classList.remove("hidden");
    } else {
      keystrokeOverlayEl.classList.add("hidden");
    }
  }

  timelineLabelEl.textContent = `${((elapsed - startedAt) / 1000).toFixed(1)}s`;
  timelineHintEl.textContent = state.isPreviewPlaying ? "Preview is playing" : "Drag to scrub the recording";
}

function stopPreview() {
  if (state.previewRequestId) {
    cancelAnimationFrame(state.previewRequestId);
    state.previewRequestId = null;
  }
  state.isPreviewPlaying = false;
  updatePreviewButtons();
}

function setPreviewProgress(progress) {
  state.previewProgress = Math.max(0, Math.min(1, progress));
  timelineRangeEl.value = String(Math.round(state.previewProgress * 1000));
  drawPreviewFrame(state.previewProgress);
}

function playPreview() {
  const trace = state.selectedTrace;
  if (!trace?.events?.length || state.isPreviewPlaying) {
    return;
  }

  state.isPreviewPlaying = true;
  state.previewStartedAt = performance.now();
  state.previewBaseProgress = state.previewProgress;
  updatePreviewButtons();

  const duration = traceDuration(trace);
  const tick = (now) => {
    const elapsed = (now - state.previewStartedAt) / duration;
    const nextProgress = Math.min(1, state.previewBaseProgress + elapsed);
    setPreviewProgress(nextProgress);

    if (nextProgress >= 1) {
      stopPreview();
      return;
    }

    state.previewRequestId = requestAnimationFrame(tick);
  };

  state.previewRequestId = requestAnimationFrame(tick);
}

function togglePreview() {
  if (state.isPreviewPlaying) {
    stopPreview();
    return;
  }

  playPreview();
}

function renderTraceDetail(trace, summary) {
  const counts = summarizeTraceActivity(trace);
  traceEmptyEl.classList.add("hidden");
  traceDetailEl.classList.remove("hidden");
  detailTitleEl.textContent = trace.name;
  detailMetaEl.textContent = `${summary.eventCount} events • ${fmtDuration(summary.durationMs)} • ${summary.initialUrl || "No starting URL"}`;
  clickCountEl.textContent = String(counts.clicks);
  keystrokeCountEl.textContent = String(counts.keystrokes);
  scrollCountEl.textContent = String(counts.scrolls);
  navigationCountEl.textContent = String(counts.navigations);
  renderEventList(trace);
  renderKeystrokeChips(trace);
  stopPreview();
  setPreviewProgress(0);
  resetPreviewUi();
}

async function loadTraces() {
  const response = await fetchJson("/api/traces");
  state.traces = response.traces;
  renderTraceList();
}

async function loadTrace(traceId) {
  const response = await fetchJson(`/api/traces/${traceId}`);
  state.selectedTraceId = traceId;
  state.selectedTrace = response.trace;
  renderTraceList();
  renderTraceDetail(response.trace, response.summary);
}

function renderJobs() {
  jobListEl.innerHTML = "";

  if (!state.jobs.length) {
    jobListEl.innerHTML = `<p class="empty-state">No render jobs yet.</p>`;
    return;
  }

  for (const job of state.jobs) {
    const article = document.createElement("article");
    article.className = "job-item";

    const outputs = (job.outputs || [])
      .map((output) => `<li><span>${escapeHtml(output.link)}</span><code>${escapeHtml(output.outputPath)}</code></li>`)
      .join("");

    const logs = (job.logs || []).map((entry) => escapeHtml(entry)).join("\n");
    const authLabel = job.auth?.type ? `${job.auth.type} (${job.auth.key || job.auth.headerName || "token"})` : "none";

    article.innerHTML = `
      <div class="job-item-top">
        <div>
          <h3>${escapeHtml(job.status.toUpperCase())}</h3>
          <p>${job.linkCount} link${job.linkCount === 1 ? "" : "s"} • ${fmtDate(job.updatedAt)}</p>
        </div>
        <span class="badge ${job.status}">${escapeHtml(job.status)}</span>
      </div>
      <p class="muted">Auth: ${escapeHtml(authLabel)}</p>
      ${job.error ? `<p class="error-copy">${escapeHtml(job.error)}</p>` : ""}
      ${outputs ? `<ul class="output-list">${outputs}</ul>` : `<p class="muted">No output files yet.</p>`}
      ${(job.error || logs) ? `
        <details class="details-card compact">
          <summary>Show Logs</summary>
          <pre class="log-block">${logs || escapeHtml(job.error || "")}</pre>
        </details>
      ` : ""}
    `;

    jobListEl.appendChild(article);
  }
}

async function loadJobs() {
  const response = await fetchJson("/api/jobs");
  state.jobs = response.jobs;
  renderJobs();
}

document.getElementById("refreshTraces").addEventListener("click", loadTraces);
document.getElementById("refreshJobs").addEventListener("click", loadJobs);
playPausePreviewBtn.addEventListener("click", togglePreview);
resetPreviewBtn.addEventListener("click", () => {
  stopPreview();
  setPreviewProgress(0);
  resetPreviewUi();
});
themeToggleBtn.addEventListener("click", () => {
  state.theme = state.theme === "dark" ? "light" : "dark";
  applyTheme();
});

timelineRangeEl.addEventListener("input", (event) => {
  stopPreview();
  setPreviewProgress(Number(event.target.value) / 1000);
});

importFormEl.addEventListener("submit", async (event) => {
  event.preventDefault();
  importStatusEl.textContent = "Uploading trace…";

  const formData = new FormData(importFormEl);

  try {
    await fetchJson("/api/import-trace", {
      method: "POST",
      body: formData
    });
    importStatusEl.textContent = "Trace uploaded.";
    importFormEl.reset();
    await loadTraces();
  } catch (error) {
    importStatusEl.textContent = error.message;
  }
});

renderFormEl.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (!state.selectedTraceId) {
    renderStatusEl.textContent = "Select a trace first.";
    return;
  }

  const links = document
    .getElementById("renderLinks")
    .value.split("\n")
    .map((item) => item.trim())
    .filter(Boolean);

  if (!links.length) {
    renderStatusEl.textContent = "Add at least one link.";
    return;
  }

  const authType = document.getElementById("authType").value;
  const authToken = document.getElementById("authToken").value.trim();
  const authKey = document.getElementById("authKey").value.trim();
  const authHeaderName = document.getElementById("authHeaderName").value.trim();

  renderStatusEl.textContent = "Queueing render job…";

  try {
    await fetchJson("/api/render", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        traceId: state.selectedTraceId,
        links,
        audioPath: document.getElementById("audioPath").value.trim(),
        speedMultiplier: Number(document.getElementById("speedMultiplier").value || 1),
        auth:
          authType !== "none" && authToken
            ? {
                type: authType,
                token: authToken,
                key: authKey,
                headerName: authHeaderName
              }
            : null
      })
    });

    renderStatusEl.textContent = "Render job queued.";
    await loadJobs();
  } catch (error) {
    renderStatusEl.textContent = error.message;
  }
});

applyTheme();
loadTraces();
loadJobs();
setInterval(loadJobs, 5000);
