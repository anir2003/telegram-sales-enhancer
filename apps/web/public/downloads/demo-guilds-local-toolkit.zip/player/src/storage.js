import { mkdir, readFile, readdir, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";

import { normalizeTrace, summarizeTrace } from "./shared/trace-utils.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const playerRoot = path.resolve(__dirname, "..");
const dataRoot = path.join(playerRoot, "data");

export const paths = {
  playerRoot,
  dataRoot,
  traces: path.join(dataRoot, "traces"),
  jobs: path.join(dataRoot, "jobs"),
  outputs: path.join(dataRoot, "outputs"),
  uploads: path.join(dataRoot, "uploads"),
  public: path.join(playerRoot, "public"),
  uiRoot: path.join(playerRoot, "ui"),
  uiDist: path.join(playerRoot, "ui", "dist")
};

async function ensureDirectory(directoryPath) {
  await mkdir(directoryPath, { recursive: true });
}

export async function ensureDataDirectories() {
  await Promise.all([
    ensureDirectory(paths.traces),
    ensureDirectory(paths.jobs),
    ensureDirectory(paths.outputs),
    ensureDirectory(paths.uploads)
  ]);
}

function jsonPathFor(directory, id) {
  return path.join(directory, `${id}.json`);
}

export async function saveTrace(tracePayload) {
  const trace = normalizeTrace(tracePayload);
  await ensureDataDirectories();
  await writeFile(jsonPathFor(paths.traces, trace.id), JSON.stringify(trace, null, 2), "utf8");
  return trace;
}

export async function getTrace(traceId) {
  const filePath = traceId.endsWith(".json") ? traceId : jsonPathFor(paths.traces, traceId);
  const content = await readFile(filePath, "utf8");
  return normalizeTrace(JSON.parse(content));
}

export async function listTraces() {
  await ensureDataDirectories();
  const files = (await readdir(paths.traces)).filter((file) => file.endsWith(".json"));
  const traces = await Promise.all(
    files.map(async (file) => {
      const content = await readFile(path.join(paths.traces, file), "utf8");
      return summarizeTrace(JSON.parse(content));
    })
  );

  return traces.sort((a, b) => b.startedAt - a.startedAt);
}

export async function saveJob(job) {
  await ensureDataDirectories();
  const finalPath = jsonPathFor(paths.jobs, job.id);
  const tempPath = path.join(paths.jobs, `.${job.id}.${process.pid}.${randomUUID()}.tmp`);
  await writeFile(tempPath, JSON.stringify(job, null, 2), "utf8");
  await rename(tempPath, finalPath);
}

export async function readJob(jobId) {
  const content = await readFile(jsonPathFor(paths.jobs, jobId), "utf8");
  return JSON.parse(content);
}

export async function listJobs() {
  await ensureDataDirectories();
  const files = (await readdir(paths.jobs)).filter((file) => file.endsWith(".json"));
  const jobs = (
    await Promise.all(
      files.map(async (file) => {
        try {
      const content = await readFile(path.join(paths.jobs, file), "utf8");
      return JSON.parse(content);
        } catch {
          return null;
        }
      })
    )
  ).filter(Boolean);

  return jobs.sort((a, b) => b.createdAt - a.createdAt);
}
