import { access, mkdir } from "node:fs/promises";
import { constants as fsConstants } from "node:fs";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

import puppeteer from "puppeteer";

import { paths } from "./storage.js";
import { createTraceVariant, normalizeTrace, sanitizeFilename } from "./shared/trace-utils.js";

const execFileAsync = promisify(execFile);
const DEFAULT_VIEWPORT = {
  width: 1440,
  height: 900,
  devicePixelRatio: 1
};
export const RENDER_CANCELLED_MESSAGE = "Render cancelled by user.";

const OVERLAY_BOOTSTRAP = `
(() => {
  if (window.__dgDemoOverlayInstalled) {
    return;
  }

  window.__dgDemoOverlayInstalled = true;

  const ensure = () => {
    if (!document.documentElement) {
      return null;
    }

    let style = document.getElementById("__dg_demo_cursor_style");
    if (!style) {
      style = document.createElement("style");
      style.id = "__dg_demo_cursor_style";
      style.textContent = \`
        #__dg_demo_cursor {
          position: fixed;
          left: 0;
          top: 0;
          width: 16px;
          height: 24px;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='24' viewBox='0 0 16 24'%3E%3Cpath d='M2.4 1.8V18.4L6.8 14.1L9.6 21.2C9.82 21.76 10.44 22.03 10.99 21.81L12.1 21.36C12.65 21.14 12.91 20.51 12.69 19.97L9.92 13.23H14.07C14.91 13.23 15.33 12.22 14.74 11.62L3.89 1.06C3.2 0.39 2.4 0.87 2.4 1.8Z' fill='white' stroke='%2309090b' stroke-width='1.15' stroke-linejoin='round'/%3E%3C/svg%3E");
          background-repeat: no-repeat;
          background-size: contain;
          transform: translate3d(-9999px, -9999px, 0);
          pointer-events: none;
          z-index: 2147483647;
          filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.28));
          transform-origin: top left;
          transition: transform 90ms ease, filter 90ms ease;
        }
        #__dg_demo_cursor.is-clicking {
          filter: drop-shadow(0 5px 10px rgba(255, 255, 255, 0.12));
        }
      \`;
      document.documentElement.appendChild(style);
    }

    let cursor = document.getElementById("__dg_demo_cursor");
    if (!cursor) {
      cursor = document.createElement("div");
      cursor.id = "__dg_demo_cursor";
      document.documentElement.appendChild(cursor);
    }

    return cursor;
  };

  window.__dgDemoOverlay = {
    ensure,
    move(x, y, clicking = false) {
      const cursor = ensure();
      if (!cursor) {
        return;
      }

      cursor.style.transform = \`translate3d(\${x}px, \${y}px, 0) scale(\${clicking ? 0.96 : 1})\`;
      cursor.classList.toggle("is-clicking", clicking);
    }
  };

  ensure();
})();`;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function distanceBetween(pointA, pointB) {
  return Math.hypot(pointA.x - pointB.x, pointA.y - pointB.y);
}

function formatExecError(error) {
  const chunks = [error.stderr, error.stdout, error.message].filter(Boolean).join("\n");
  return chunks
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(-12)
    .join("\n");
}

function mapRecordedPoint(event, viewport) {
  const x =
    typeof event.normalizedX === "number"
      ? event.normalizedX * viewport.width
      : (event.clientX || 0) * (viewport.width / (event.viewport?.width || viewport.width));

  const y =
    typeof event.normalizedY === "number"
      ? event.normalizedY * viewport.height
      : (event.clientY || 0) * (viewport.height / (event.viewport?.height || viewport.height));

  return {
    x: clamp(Math.round(x), 1, viewport.width - 1),
    y: clamp(Math.round(y), 1, viewport.height - 1)
  };
}

async function moveCursor(page, point, clicking = false) {
  await page.mouse.move(point.x, point.y);
  await page.evaluate(
    ({ x, y, isClicking }) => {
      window.__dgDemoOverlay?.move(x, y, isClicking);
    },
    {
      x: point.x,
      y: point.y,
      isClicking: clicking
    }
  );
}

function choosePlaybackPoint(fallbackPoint, resolvedPoint, viewport) {
  if (!resolvedPoint) {
    return fallbackPoint;
  }

  const maxSnapDistance = Math.max(96, Math.min(viewport.width, viewport.height) * 0.14);
  return distanceBetween(fallbackPoint, resolvedPoint) <= maxSnapDistance ? resolvedPoint : fallbackPoint;
}

async function resolvePositionFromTarget(page, target) {
  if (!target || !Array.isArray(target.selectors)) {
    return null;
  }

  for (const selector of target.selectors) {
    try {
      const handle = await page.$(selector);
      if (!handle) {
        continue;
      }

      const box = await handle.boundingBox();
      await handle.dispose();

      if (box) {
        return {
          x: Math.round(box.x + box.width / 2),
          y: Math.round(box.y + box.height / 2)
        };
      }
    } catch {
      continue;
    }
  }

  if (target.text) {
    const position = await page.evaluate(({ text, tagName }) => {
      const candidates = Array.from(document.querySelectorAll(tagName || "*"));
      const match = candidates.find((element) =>
        (element.innerText || element.textContent || "").trim().includes(text)
      );

      if (!match) {
        return null;
      }

      const rect = match.getBoundingClientRect();
      return {
        x: Math.round(rect.left + rect.width / 2),
        y: Math.round(rect.top + rect.height / 2)
      };
    }, { text: target.text, tagName: target.tagName });

    if (position) {
      return position;
    }
  }

  return null;
}

async function focusAndSetValue(page, target, value, checked = null) {
  if (!target || !Array.isArray(target.selectors) || (value === null && typeof checked !== "boolean")) {
    return false;
  }

  for (const selector of target.selectors) {
    try {
      const updated = await page.evaluate(
        ({ query, nextValue, nextChecked }) => {
          const element = document.querySelector(query);
          if (!element) {
            return false;
          }

          element.focus();

          if ("value" in element) {
            const descriptor = Object.getOwnPropertyDescriptor(element.__proto__, "value");
            if (descriptor?.set) {
              descriptor.set.call(element, nextValue);
            } else {
              element.value = nextValue;
            }
          }

          if (typeof nextChecked === "boolean" && "checked" in element) {
            element.checked = nextChecked;
          }

          element.dispatchEvent(new Event("input", { bubbles: true }));
          element.dispatchEvent(new Event("change", { bubbles: true }));
          return true;
        },
        {
          query: selector,
          nextValue: value,
          nextChecked: checked
        }
      );

      if (updated) {
        return true;
      }
    } catch {
      continue;
    }
  }

  return false;
}

function normalizeKey(key) {
  const mappings = {
    " ": "Space",
    ArrowLeft: "ArrowLeft",
    ArrowRight: "ArrowRight",
    ArrowUp: "ArrowUp",
    ArrowDown: "ArrowDown",
    Enter: "Enter",
    Tab: "Tab",
    Backspace: "Backspace",
    Escape: "Escape",
    Delete: "Delete",
    Meta: "Meta",
    Control: "Control",
    Shift: "Shift",
    Alt: "Alt"
  };

  return mappings[key] || key;
}

function shouldReplayKeyEvent(event) {
  if (!event?.key) {
    return false;
  }

  const replayableKeys = new Set([
    "Enter",
    "Tab",
    "Escape",
    "Backspace",
    "Delete",
    "ArrowLeft",
    "ArrowRight",
    "ArrowUp",
    "ArrowDown",
    "Home",
    "End",
    "PageUp",
    "PageDown"
  ]);

  return replayableKeys.has(event.key);
}

function mouseButtonFromEvent(event) {
  if (event?.button === 1) {
    return "middle";
  }

  if (event?.button === 2) {
    return "right";
  }

  return "left";
}

function eventPointsMatch(eventA, eventB) {
  const xA = typeof eventA?.clientX === "number" ? eventA.clientX : eventA?.normalizedX;
  const yA = typeof eventA?.clientY === "number" ? eventA.clientY : eventA?.normalizedY;
  const xB = typeof eventB?.clientX === "number" ? eventB.clientX : eventB?.normalizedX;
  const yB = typeof eventB?.clientY === "number" ? eventB.clientY : eventB?.normalizedY;

  if (typeof xA !== "number" || typeof yA !== "number" || typeof xB !== "number" || typeof yB !== "number") {
    return false;
  }

  return Math.abs(xA - xB) <= 6 && Math.abs(yA - yB) <= 6;
}

function hasNeighboringClick(events, index) {
  const current = events[index];
  if (!current || (current.type !== "POINTER_DOWN" && current.type !== "POINTER_UP")) {
    return false;
  }

  for (let cursor = index + 1; cursor < events.length; cursor += 1) {
    const candidate = events[cursor];
    if (!candidate) {
      continue;
    }

    if (candidate.at - current.at > 420) {
      break;
    }

    if (
      (candidate.type === "CLICK" || candidate.type === "DOUBLE_CLICK") &&
      candidate.at - current.at <= 320 &&
      eventPointsMatch(current, candidate)
    ) {
      return true;
    }

    if (candidate.type === "POINTER_MOVE" && !eventPointsMatch(current, candidate)) {
      break;
    }
  }

  return false;
}

function hasNeighboringDoubleClick(events, index) {
  const current = events[index];
  if (!current || current.type !== "CLICK") {
    return false;
  }

  for (let cursor = index + 1; cursor < events.length; cursor += 1) {
    const candidate = events[cursor];
    if (!candidate) {
      continue;
    }

    if (candidate.at - current.at > 500) {
      break;
    }

    if (candidate.type === "DOUBLE_CLICK" && candidate.at - current.at <= 420 && eventPointsMatch(current, candidate)) {
      return true;
    }
  }

  return false;
}

async function ensureButtonReleased(page, pressedButtons, button) {
  if (!pressedButtons.has(button)) {
    return false;
  }

  try {
    await page.mouse.up({ button });
  } catch {
    // If the browser state is already reset, continue and clear local state.
  }

  pressedButtons.delete(button);
  return true;
}

async function ensureButtonPressed(page, pressedButtons, button) {
  if (pressedButtons.has(button)) {
    return false;
  }

  await page.mouse.down({ button });
  pressedButtons.add(button);
  return true;
}

async function releaseAllButtons(page, pressedButtons) {
  for (const button of [...pressedButtons]) {
    await ensureButtonReleased(page, pressedButtons, button);
  }
}

async function maybeGoto(page, nextUrl, options = {}) {
  if (!nextUrl) {
    return;
  }

  if (page.url() === nextUrl) {
    return;
  }

  const waitUntil = options.waitUntil || "domcontentloaded";
  const timeout = Number(options.timeout || 10000);

  try {
    await page.goto(nextUrl, { waitUntil, timeout });
  } catch {
    try {
      await page.goto(nextUrl, { waitUntil: "load", timeout });
    } catch {
      // Keep going and let later events recover if the page is still settling.
    }
  }
}

async function waitForUrl(page, nextUrl, timeout = 1500) {
  const deadline = Date.now() + timeout;

  while (Date.now() < deadline) {
    if (page.url() === nextUrl) {
      return true;
    }

    await sleep(100);
  }

  return page.url() === nextUrl;
}

async function syncNavigationToUrl(page, nextUrl, options = {}) {
  if (!nextUrl) {
    return;
  }

  if (page.url() === nextUrl) {
    return;
  }

  const settled = await waitForUrl(page, nextUrl, Number(options.waitTimeout || 1500));
  if (settled) {
    return;
  }

  await maybeGoto(page, nextUrl, {
    waitUntil: options.waitUntil || "domcontentloaded",
    timeout: Number(options.timeout || 5000)
  });
}

function normalizeAuthEntries(auth) {
  if (!auth) {
    return [];
  }

  if (Array.isArray(auth.entries)) {
    return auth.entries
      .map((entry) => ({
        key: String(entry?.key || "").trim(),
        value: String(entry?.value ?? "")
      }))
      .filter((entry) => entry.key && entry.value !== "");
  }

  if (auth.key && auth.token) {
    return [
      {
        key: String(auth.key).trim(),
        value: String(auth.token)
      }
    ];
  }

  return [];
}

function normalizeAuth(auth) {
  if (!auth || !auth.type) {
    return null;
  }

  const entries = normalizeAuthEntries(auth);
  if (!entries.length) {
    return null;
  }

  return {
    type: auth.type,
    entries
  };
}

function shouldRefreshAfterAuth(auth) {
  const normalized = normalizeAuth(auth);
  return normalized?.type === "localStorage" || normalized?.type === "sessionStorage";
}

async function installAuth(page, auth, targetUrl) {
  const normalized = normalizeAuth(auth);
  if (!normalized || !targetUrl) {
    return;
  }

  let target;
  try {
    target = new URL(targetUrl);
  } catch {
    return;
  }

  const origin = target.origin;

  if (normalized.type === "cookie") {
    await page.setCookie(
      ...normalized.entries.map((entry) => ({
        name: entry.key,
        value: entry.value,
        url: origin,
        path: "/"
      }))
    );
    return;
  }

  if (normalized.type === "header") {
    const headers = Object.fromEntries(
      normalized.entries.map((entry) => {
        if (entry.key.toLowerCase() === "authorization" && !/^bearer\s/i.test(entry.value)) {
          return [entry.key, `Bearer ${entry.value}`];
        }

        return [entry.key, entry.value];
      })
    );

    await page.setExtraHTTPHeaders(headers);
    return;
  }

  if (normalized.type === "localStorage" || normalized.type === "sessionStorage") {
    const storageArea = normalized.type;
    await page.evaluateOnNewDocument(
      ({ expectedOrigin, storageKind, entries }) => {
        const apply = () => {
          if (window.location.origin !== expectedOrigin) {
            return;
          }

          const storage = storageKind === "sessionStorage" ? window.sessionStorage : window.localStorage;
          for (const entry of entries) {
            storage.setItem(entry.key, entry.value);
          }
        };

        apply();
        window.addEventListener("DOMContentLoaded", apply, { once: true });
      },
      {
        expectedOrigin: origin,
        storageKind: storageArea,
        entries: normalized.entries
      }
    );
  }
}

export async function preparePageAuth(page, auth, targetUrl) {
  await installAuth(page, auth, targetUrl);

  if (!targetUrl) {
    return;
  }

  await maybeGoto(page, targetUrl, { waitUntil: "domcontentloaded", timeout: 15000 });

  if (shouldRefreshAfterAuth(auth)) {
    try {
      await page.reload({ waitUntil: "networkidle2" });
    } catch {
      await page.reload({ waitUntil: "load" });
    }
  }
}

async function ensureOverlay(page) {
  await page.evaluateOnNewDocument(OVERLAY_BOOTSTRAP);
  await page.evaluate(OVERLAY_BOOTSTRAP);
}

async function ffmpegAvailable() {
  try {
    await execFileAsync("ffmpeg", ["-version"]);
    return true;
  } catch {
    return false;
  }
}

async function probeVideoTiming(rawVideoPath) {
  try {
    const { stdout } = await execFileAsync("ffprobe", [
      "-v",
      "error",
      "-count_packets",
      "-select_streams",
      "v:0",
      "-show_entries",
      "stream=r_frame_rate,avg_frame_rate,nb_read_packets",
      "-of",
      "json",
      rawVideoPath
    ]);

    const payload = JSON.parse(stdout);
    const stream = payload.streams?.[0];
    const frameRate = stream?.avg_frame_rate || stream?.r_frame_rate || "25/1";
    const [numerator, denominator] = String(frameRate)
      .split("/")
      .map((value) => Number(value));
    const fps = numerator > 0 && denominator > 0 ? numerator / denominator : 25;
    const frameCount = Number(stream?.nb_read_packets || 0);

    if (!fps || !frameCount) {
      return null;
    }

    return {
      fps,
      frameCount,
      nominalDurationSec: frameCount / fps
    };
  } catch {
    return null;
  }
}

async function mergeVideo(rawVideoPath, outputBasePath, audioPath = null, options = {}) {
  const canUseFfmpeg = await ffmpegAvailable();

  if (!canUseFfmpeg) {
    return rawVideoPath;
  }

  const outputPath = `${outputBasePath}.mp4`;
  const args = ["-y", "-i", rawVideoPath];
  let videoFilter = "pad=ceil(iw/2)*2:ceil(ih/2)*2";
  const desiredDurationSec = Number(options.desiredDurationSec || 0);

  if (desiredDurationSec > 0) {
    const timing = await probeVideoTiming(rawVideoPath);
    if (timing?.nominalDurationSec) {
      const setptsFactor = desiredDurationSec / timing.nominalDurationSec;
      if (Number.isFinite(setptsFactor) && setptsFactor > 0 && Math.abs(setptsFactor - 1) > 0.01) {
        videoFilter = `setpts=${setptsFactor.toFixed(6)}*PTS,${videoFilter}`;
      }
    }
  }

  if (audioPath) {
    args.push(
      "-i",
      audioPath,
      "-vf",
      videoFilter,
      "-af",
      "apad",
      "-c:v",
      "libx264",
      "-preset",
      "medium",
      "-pix_fmt",
      "yuv420p",
      "-movflags",
      "+faststart",
      "-c:a",
      "aac",
      "-shortest",
      outputPath
    );
  } else {
    args.push(
      "-vf",
      videoFilter,
      "-c:v",
      "libx264",
      "-preset",
      "medium",
      "-pix_fmt",
      "yuv420p",
      "-movflags",
      "+faststart",
      outputPath
    );
  }

  try {
    await execFileAsync("ffmpeg", args);
  } catch (error) {
    throw new Error(`FFmpeg could not encode the render.\n${formatExecError(error)}`);
  }
  return outputPath;
}

async function assertAudioPath(audioPath) {
  if (!audioPath) {
    return;
  }

  await access(audioPath, fsConstants.R_OK);
}

async function waitForRenderControl(options = {}) {
  if (typeof options.shouldCancel === "function" && options.shouldCancel()) {
    throw new Error(RENDER_CANCELLED_MESSAGE);
  }

  const pausedMs = typeof options.waitIfPaused === "function" ? await options.waitIfPaused() : 0;

  if (typeof options.shouldCancel === "function" && options.shouldCancel()) {
    throw new Error(RENDER_CANCELLED_MESSAGE);
  }

  return Number(pausedMs || 0);
}

async function sleepWithRenderControl(ms, options = {}) {
  const startedAt = Date.now();
  let pausedTotalMs = 0;

  while (Date.now() - startedAt - pausedTotalMs < ms) {
    pausedTotalMs += await waitForRenderControl(options);
    const remainingMs = ms - (Date.now() - startedAt - pausedTotalMs);

    if (remainingMs > 0) {
      await sleep(Math.min(remainingMs, 250));
    }
  }

  return pausedTotalMs;
}

async function pathExists(filePath) {
  try {
    await access(filePath, fsConstants.F_OK);
    return true;
  } catch {
    return false;
  }
}

async function createUniqueOutputBasePath(directoryPath, baseName) {
  await mkdir(directoryPath, { recursive: true });

  const safeBaseName = sanitizeFilename(baseName).replace(/^\.+|\.+$/g, "") || "output";
  let candidate = path.join(directoryPath, safeBaseName);
  let suffix = 2;

  while (await pathExists(`${candidate}.mp4`) || await pathExists(`${candidate}.webm`)) {
    candidate = path.join(directoryPath, `${safeBaseName}-${suffix}`);
    suffix += 1;
  }

  return candidate;
}

function buildPlaybackEvents(events, options = {}) {
  const hasScrollEvents = Boolean(options.hasScrollEvents);
  const pointerMoveSampleWindowMs = 64;
  const scrollSampleWindowMs = 64;
  const playback = [];

  for (let index = 0; index < events.length; index += 1) {
    const event = events[index];
    if (!event) {
      continue;
    }

    if (hasScrollEvents && event.type === "WHEEL") {
      continue;
    }

    if ((event.type === "KEY_DOWN" || event.type === "KEY_UP") && !shouldReplayKeyEvent(event)) {
      continue;
    }

    if (event.type === "SCROLL") {
      let chosenEvent = event;
      let chosenIndex = index;

      for (let cursor = index + 1; cursor < events.length; cursor += 1) {
        const candidate = events[cursor];
        if (!candidate) {
          continue;
        }

        if (!["WHEEL", "SCROLL"].includes(candidate.type)) {
          break;
        }

        if (candidate.at - event.at > scrollSampleWindowMs) {
          break;
        }

        if (candidate.type === "SCROLL") {
          chosenEvent = candidate;
          chosenIndex = cursor;
        }
      }

      playback.push({
        ...chosenEvent,
        __sourceIndex: chosenIndex
      });

      index = chosenIndex;
      continue;
    }

    if (event.type === "POINTER_MOVE") {
      let chosenEvent = event;
      let chosenIndex = index;

      for (let cursor = index + 1; cursor < events.length; cursor += 1) {
        const candidate = events[cursor];
        if (!candidate || candidate.type !== "POINTER_MOVE") {
          break;
        }

        if (candidate.at - event.at > pointerMoveSampleWindowMs) {
          break;
        }

        chosenEvent = candidate;
        chosenIndex = cursor;
      }

      playback.push({
        ...chosenEvent,
        __sourceIndex: chosenIndex
      });

      index = chosenIndex;
      continue;
    }

    playback.push({
      ...event,
      __sourceIndex: index
    });
  }

  return playback;
}

export async function renderTraceToVideo(tracePayload, options) {
  const trace = createTraceVariant(normalizeTrace(tracePayload), options.targetUrl);
  const viewport = {
    ...DEFAULT_VIEWPORT,
    ...(trace.meta.sourceViewport || {})
  };
  const hasScrollEvents = trace.events.some((event) => event.type === "SCROLL");
  const playbackEvents = buildPlaybackEvents(trace.events, { hasScrollEvents });
  const firstEventAt = trace.events[0]?.at || trace.startedAt;
  const lastEventAt = trace.events[trace.events.length - 1]?.at || firstEventAt;
  const totalTraceDurationMs = Math.max(1, lastEventAt - firstEventAt);

  await assertAudioPath(options.audioPath);

  const outputDirectory = options.outputDirectory ? path.resolve(options.outputDirectory) : paths.outputs;
  const outputBaseName = options.outputName || `${Date.now()}-${sanitizeFilename(options.targetUrl || trace.name)}`;
  const outputBasePath = await createUniqueOutputBasePath(outputDirectory, outputBaseName);
  const rawVideoPath = `${outputBasePath}.webm`;

  const browser = await puppeteer.launch({
    headless: true,
    defaultViewport: null,
    args: [`--window-size=${viewport.width},${viewport.height}`]
  });

  let recorder = null;
  const progressStartedAt = Date.now();
  let lastProgressPercent = -1;
  let lastProgressStage = "";
  let lastProgressEmitAt = 0;

  try {
    const page = await browser.newPage();
    const pressedButtons = new Set();

    const emitProgress = async (stage, percent, extra = {}) => {
      if (typeof options.onProgress !== "function") {
        return;
      }

      const safePercent = clamp(percent, 0, 100);
      const now = Date.now();
      const force = Boolean(extra.force);

      if (
        !force &&
        stage === lastProgressStage &&
        Math.abs(safePercent - lastProgressPercent) < 1 &&
        now - lastProgressEmitAt < 800
      ) {
        return;
      }

      lastProgressPercent = safePercent;
      lastProgressStage = stage;
      lastProgressEmitAt = now;

      const elapsedMs = now - progressStartedAt;
      const etaMs =
        safePercent > 0 && safePercent < 100
          ? Math.round((elapsedMs * (100 - safePercent)) / safePercent)
          : safePercent >= 100
            ? 0
            : null;

      await options.onProgress({
        stage,
        percent: safePercent,
        elapsedMs,
        etaMs,
        ...extra
      });
    };

    await emitProgress("preparing", 1, { force: true, processedEvents: 0, totalEvents: trace.events.length });

    await page.setViewport({
      width: viewport.width,
      height: viewport.height,
      deviceScaleFactor: viewport.devicePixelRatio || 1
    });
    await ensureOverlay(page);
    const targetUrl = trace.meta.targetUrl || trace.meta.initialUrl || options.targetUrl;
    await preparePageAuth(page, options.auth || null, targetUrl);
    await emitProgress("preparing", 4, { processedEvents: 0, totalEvents: trace.events.length });

    await page.evaluate(() => window.__dgDemoOverlay?.move(12, 12, false));

    if (typeof page.screencast !== "function") {
      throw new Error("Installed Puppeteer version does not expose page.screencast().");
    }

    recorder = await page.screencast({
      path: rawVideoPath,
      fps: 30
    });

    if (Number(options.startDelayMs) > 0) {
      await emitProgress("waiting", 5, { processedEvents: 0, totalEvents: trace.events.length });
      await sleepWithRenderControl(Number(options.startDelayMs), options);
    }

    let replayTimelineStartAt = Date.now();
    const effectiveSpeedMultiplier = options.speedMultiplier || 1;

    for (const [playbackIndex, event] of playbackEvents.entries()) {
      replayTimelineStartAt += await waitForRenderControl(options);
      const sourceIndex = typeof event.__sourceIndex === "number" ? event.__sourceIndex : playbackIndex;
      const scheduledOffsetMs = Math.max(0, event.at - firstEventAt) / effectiveSpeedMultiplier;
      const waitTime = replayTimelineStartAt + scheduledOffsetMs - Date.now();
      if (waitTime > 1) {
        replayTimelineStartAt += await sleepWithRenderControl(waitTime, options);
      }

      const fallbackPoint = mapRecordedPoint(event, viewport);
      const resolvedPoint = ["CLICK", "DOUBLE_CLICK", "INPUT", "CHANGE"].includes(event.type)
        ? choosePlaybackPoint(
          fallbackPoint,
          await resolvePositionFromTarget(page, event.target),
          viewport
        )
        : fallbackPoint;

      switch (event.type) {
        case "POINTER_MOVE":
          await moveCursor(page, fallbackPoint);
          break;
        case "POINTER_DOWN":
          if (hasNeighboringClick(trace.events, sourceIndex)) {
            break;
          }

          await moveCursor(page, fallbackPoint, true);
          await ensureButtonPressed(page, pressedButtons, mouseButtonFromEvent(event));
          break;
        case "POINTER_UP":
          if (hasNeighboringClick(trace.events, sourceIndex)) {
            break;
          }

          await moveCursor(page, fallbackPoint);
          await ensureButtonReleased(page, pressedButtons, mouseButtonFromEvent(event));
          break;
        case "CLICK":
          if (hasNeighboringDoubleClick(trace.events, sourceIndex)) {
            break;
          }

          await ensureButtonReleased(page, pressedButtons, mouseButtonFromEvent(event));
          await moveCursor(page, fallbackPoint, true);
          await page.mouse.click(resolvedPoint.x, resolvedPoint.y, {
            button: mouseButtonFromEvent(event),
            delay: 40
          });
          await moveCursor(page, fallbackPoint);
          break;
        case "DOUBLE_CLICK":
          await ensureButtonReleased(page, pressedButtons, mouseButtonFromEvent(event));
          await moveCursor(page, fallbackPoint, true);
          await page.mouse.click(resolvedPoint.x, resolvedPoint.y, {
            button: mouseButtonFromEvent(event),
            clickCount: 2,
            delay: 40
          });
          await moveCursor(page, fallbackPoint);
          break;
        case "WHEEL":
          if (hasScrollEvents) {
            break;
          }

          await moveCursor(page, fallbackPoint);
          await page.mouse.wheel({
            deltaX: event.deltaX || 0,
            deltaY: event.deltaY || 0
          });
          break;
        case "SCROLL":
          if (event.scrollTarget === "element" && event.target) {
            await page.evaluate(
              ({ selectors, top, left }) => {
                for (const selector of selectors || []) {
                  const element = document.querySelector(selector);
                  if (element) {
                    element.scrollTo({
                      top,
                      left,
                      behavior: "auto"
                    });
                    return;
                  }
                }
                window.scrollTo({ top, left, behavior: "auto" });
              },
              {
                selectors: event.target.selectors,
                top: event.scrollTop || 0,
                left: event.scrollLeft || 0
              }
            );
          } else {
            await page.evaluate(
              ({ x, y }) => window.scrollTo({ top: y, left: x, behavior: "auto" }),
              {
                x: event.pageScrollX || 0,
                y: event.pageScrollY || 0
              }
            );
          }
          break;
        case "KEY_DOWN":
          if (!shouldReplayKeyEvent(event)) {
            break;
          }

          try {
            await page.keyboard.down(normalizeKey(event.key));
          } catch {
            // Unsupported keys can be safely skipped.
          }
          break;
        case "KEY_UP":
          if (!shouldReplayKeyEvent(event)) {
            break;
          }

          try {
            await page.keyboard.up(normalizeKey(event.key));
          } catch {
            // Unsupported keys can be safely skipped.
          }
          break;
        case "INPUT":
        case "CHANGE":
          if (event.target && (event.value !== null || typeof event.checked === "boolean")) {
            await focusAndSetValue(page, event.target, event.value, event.checked);
          }
          break;
        case "TAB_ACTIVATED":
        case "TAB_URL_UPDATED":
        case "URL_CHANGED":
        case "NAVIGATION_COMMITTED":
          await releaseAllButtons(page, pressedButtons);
          await syncNavigationToUrl(page, event.url, {
            waitTimeout: 1500,
            waitUntil: "domcontentloaded",
            timeout: 5000
          });
          break;
        default:
          break;
      }

      const replayPercent = 5 + ((event.at - firstEventAt) / totalTraceDurationMs) * 87;
      await emitProgress("replaying", replayPercent, {
        processedEvents: sourceIndex + 1,
        totalEvents: trace.events.length
      });
    }

    await releaseAllButtons(page, pressedButtons);
    await emitProgress("finishing", 94, {
      processedEvents: trace.events.length,
      totalEvents: trace.events.length
    });

    if (recorder?.stop) {
      await recorder.stop();
    }

    await browser.close();
    await emitProgress("encoding", options.audioPath ? 97 : 99, {
      processedEvents: trace.events.length,
      totalEvents: trace.events.length
    });
    const outputPath = await mergeVideo(rawVideoPath, outputBasePath, options.audioPath || null, {
      desiredDurationSec:
        Math.max(0, lastEventAt - firstEventAt) / effectiveSpeedMultiplier / 1000 +
        Number(options.startDelayMs || 0) / 1000
    });
    await emitProgress("completed", 100, {
      processedEvents: trace.events.length,
      totalEvents: trace.events.length,
      force: true
    });

    return {
      outputPath,
      rawVideoPath
    };
  } catch (error) {
    if (recorder?.stop) {
      try {
        await recorder.stop();
      } catch {
        // Ignore recorder shutdown errors on failed runs.
      }
    }

    await browser.close();
    throw error;
  }
}
