import express from "express";
import multer from "multer";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { execFile } from "node:child_process";
import { writeFile } from "node:fs/promises";
import { promisify } from "node:util";

import { RENDER_CANCELLED_MESSAGE, renderTraceToVideo } from "./render.js";
import { ensureDataDirectories, getTrace, listJobs, listTraces, paths, readJob, saveJob, saveTrace } from "./storage.js";
import { normalizeTrace, summarizeTrace } from "./shared/trace-utils.js";

const upload = multer({ storage: multer.memoryStorage() });
const app = express();
const port = Number(process.env.PORT || 4312);
const maxRenderConcurrency = Math.max(1, Number(process.env.RENDER_CONCURRENCY_MAX || 2));
const execFileAsync = promisify(execFile);
const activeJobs = new Map();
const activeRunners = new Set();
const jobSaveChains = new Map();
const jobControls = new Map();

function createJobControl() {
  return {
    paused: false,
    cancelRequested: false,
    waiters: new Set()
  };
}

function getJobControl(jobId) {
  if (!jobControls.has(jobId)) {
    jobControls.set(jobId, createJobControl());
  }

  return jobControls.get(jobId);
}

function wakeJobControl(control) {
  for (const resolve of control.waiters) {
    resolve();
  }
  control.waiters.clear();
}

app.use((request, response, next) => {
  response.setHeader("Access-Control-Allow-Origin", "*");
  response.setHeader("Access-Control-Allow-Headers", "Content-Type");
  response.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");

  if (request.method === "OPTIONS") {
    response.sendStatus(204);
    return;
  }

  next();
});

app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true }));
app.use("/outputs", express.static(paths.outputs));
app.use("/uploads", express.static(paths.uploads));
app.use(express.static(paths.uiDist));

function buildJobSummary(job) {
  const items = Array.isArray(job.items) && job.items.length
    ? job.items
    : (job.links || []).map((link, index) => ({ id: `item-${index + 1}`, name: "", link }));

  return {
    id: job.id,
    traceId: job.traceId,
    status: job.status,
    createdAt: job.createdAt,
    updatedAt: job.updatedAt,
    linkCount: items.length,
    items,
    outputs: job.outputs || [],
    error: job.error || null,
    errors: job.errors || [],
    auth: job.auth?.type
      ? {
          type: job.auth.type,
          entryCount: Array.isArray(job.auth.entries) ? job.auth.entries.length : 0
        }
      : null,
    startDelaySeconds: job.startDelaySeconds || 0,
    outputDirectory: job.outputDirectory || paths.outputs,
    concurrency: job.concurrency || 1,
    progress: job.progress || null,
    itemStatuses: job.itemStatuses || [],
    logs: job.logs || []
  };
}

async function updateJob(job) {
  job.updatedAt = Date.now();
  activeJobs.set(job.id, job);
  const snapshot = structuredClone(job);
  const previousSave = jobSaveChains.get(job.id) || Promise.resolve();
  const nextSave = previousSave
    .catch(() => {})
    .then(() => saveJob(snapshot));
  jobSaveChains.set(job.id, nextSave);
  await nextSave;
  return job;
}

function normalizeBatchItems({ items, links }) {
  const sourceItems = Array.isArray(items) && items.length ? items : links;

  if (!Array.isArray(sourceItems)) {
    return [];
  }

  return sourceItems
    .map((item, index) => {
      if (typeof item === "string") {
        return {
          id: `item-${index + 1}`,
          name: "",
          link: item.trim()
        };
      }

      return {
        id: String(item?.id || `item-${index + 1}`),
        name: String(item?.name || item?.companyName || item?.company || "").trim(),
        link: String(item?.link || item?.url || "").trim()
      };
    })
    .filter((item) => item.link);
}

function clampConcurrency(value) {
  return Math.min(maxRenderConcurrency, Math.max(1, Number(value) || 1));
}

function createInitialItemStatuses(items) {
  return items.map((item, index) => ({
    id: item.id || `item-${index + 1}`,
    index,
    name: item.name || "",
    link: item.link,
    status: "queued",
    progress: 0,
    processedEvents: 0,
    error: null,
    outputPath: null
  }));
}

function normalizeItemStatuses(job, items, traceEventCount, resume) {
  if (!resume || !Array.isArray(job.itemStatuses) || !job.itemStatuses.length) {
    return createInitialItemStatuses(items);
  }

  const statuses = items.map((item, index) => {
    const existing = job.itemStatuses.find((status) => status.index === index || status.id === item.id || status.link === item.link);
    const output = (job.outputs || []).find((candidate) => candidate.itemIndex === index || candidate.itemId === item.id || candidate.link === item.link);
    const isCompleted = existing?.status === "completed" || Boolean(output?.outputPath);

    return {
      id: item.id || existing?.id || `item-${index + 1}`,
      index,
      name: item.name || existing?.name || "",
      link: item.link,
      status: isCompleted ? "completed" : "queued",
      progress: isCompleted ? 100 : 0,
      processedEvents: isCompleted ? traceEventCount : 0,
      error: isCompleted ? null : null,
      outputPath: output?.outputPath || existing?.outputPath || null
    };
  });

  return statuses;
}

function countItemStatuses(itemStatuses) {
  return itemStatuses.reduce(
    (counts, item) => {
      counts[item.status] = (counts[item.status] || 0) + 1;
      return counts;
    },
    { queued: 0, running: 0, completed: 0, failed: 0, cancelled: 0 }
  );
}

function isTerminalStatus(status) {
  return ["completed", "completed_with_errors", "failed", "cancelled"].includes(status);
}

async function chooseOutputDirectory() {
  if (process.platform !== "darwin") {
    throw new Error("Native folder selection is currently implemented for macOS. Paste an absolute folder path instead.");
  }

  const { stdout } = await execFileAsync(
    "osascript",
    ["-e", 'POSIX path of (choose folder with prompt "Choose export folder for rendered videos")'],
    { timeout: 120000 }
  );

  return stdout.trim().replace(/\/+$/, "") || paths.outputs;
}

async function runRenderJob(jobId, options = {}) {
  if (activeRunners.has(jobId)) {
    return;
  }

  activeRunners.add(jobId);
  const control = getJobControl(jobId);
  control.cancelRequested = false;

  try {
    const job = activeJobs.get(jobId) || (await readJob(jobId));
    const trace = await getTrace(job.traceId);
    const items = normalizeBatchItems({ items: job.items, links: job.links });
    const totalItems = items.length;
    const traceEventCount = trace.events.length;
    const resume = Boolean(options.resume);

    job.status = "running";
    job.error = null;
    job.items = items;
    job.links = items.map((item) => item.link);
    job.outputs = resume && Array.isArray(job.outputs) ? job.outputs : [];
    job.errors = resume && Array.isArray(job.errors) ? job.errors : [];
    job.itemStatuses = normalizeItemStatuses(job, items, traceEventCount, resume);
    job.logs = job.logs || [];
    job.renderStartedAt = Date.now();
    job.logs.push(`Using trace "${trace.name}" (${trace.id}) with ${trace.events.length} events.`);
    job.logs.push(`${resume ? "Resuming" : "Rendering"} ${totalItems} item${totalItems === 1 ? "" : "s"} with concurrency ${job.concurrency || 1}.`);

    const progressByItem = job.itemStatuses.map((item) => Number(item.progress || 0));
    const processedEventsByItem = job.itemStatuses.map((item) => Number(item.processedEvents || 0));
    const remainingIndexes = job.itemStatuses
      .filter((item) => item.status !== "completed")
      .map((item) => item.index);
    let nextCursor = 0;

    const updateOverallProgress = async (stage = "replaying", currentLabel = "") => {
      const counts = countItemStatuses(job.itemStatuses);
      const percent = totalItems
        ? progressByItem.reduce((sum, value) => sum + value, 0) / totalItems
        : 0;
      const elapsedMs = Date.now() - job.renderStartedAt;
      const etaMs =
        percent > 0 && percent < 100 && !["paused", "canceling", "cancelled"].includes(stage)
          ? Math.round((elapsedMs * (100 - percent)) / percent)
          : percent >= 100
            ? 0
            : null;

      job.progress = {
        percent: Math.round(percent * 10) / 10,
        stage,
        etaMs,
        currentLink: Math.min(totalItems, counts.completed + counts.failed + counts.cancelled + counts.running),
        totalLinks: totalItems,
        activeLinks: counts.running,
        completedLinks: counts.completed,
        failedLinks: counts.failed,
        cancelledLinks: counts.cancelled,
        queuedLinks: counts.queued,
        currentLabel,
        processedEvents: processedEventsByItem.reduce((sum, value) => sum + value, 0),
        totalEvents: traceEventCount * totalItems
      };

      await updateJob(job);
    };

    const waitIfPaused = async (label = "") => {
      if (control.cancelRequested) {
        throw new Error(RENDER_CANCELLED_MESSAGE);
      }

      if (!control.paused) {
        return 0;
      }

      const pausedAt = Date.now();
      job.status = "paused";
      await updateOverallProgress("paused", label);

      while (control.paused && !control.cancelRequested) {
        await new Promise((resolve) => {
          control.waiters.add(resolve);
        });
      }

      if (control.cancelRequested) {
        throw new Error(RENDER_CANCELLED_MESSAGE);
      }

      job.status = "running";
      await updateOverallProgress("replaying", label);
      return Date.now() - pausedAt;
    };

    const renderItem = async (item, index) => {
      const label = item.name || item.link;
      const itemStatus = job.itemStatuses[index];
      itemStatus.status = "running";
      itemStatus.error = null;
      job.logs.push(`Rendering ${label}: ${item.link}`);
      await updateOverallProgress("preparing", label);

      try {
        const result = await renderTraceToVideo(trace, {
          targetUrl: item.link,
          audioPath: job.audioPath || null,
          speedMultiplier: job.speedMultiplier || 1,
          auth: job.auth || null,
          startDelayMs: Number(job.startDelaySeconds || 0) * 1000,
          outputDirectory: job.outputDirectory || paths.outputs,
          outputName: item.name || undefined,
          shouldCancel: () => control.cancelRequested,
          waitIfPaused: () => waitIfPaused(label),
          onProgress: async (progress) => {
            const nextProgress = progress.percent || 0;
            progressByItem[index] = nextProgress;
            processedEventsByItem[index] = progress.processedEvents || 0;
            itemStatus.progress = Math.round(nextProgress * 10) / 10;
            itemStatus.processedEvents = progress.processedEvents || 0;
            await updateOverallProgress(control.paused ? "paused" : progress.stage || "replaying", label);
          }
        });

        const output = {
          itemId: item.id,
          itemIndex: index,
          name: item.name || "",
          link: item.link,
          outputPath: result.outputPath,
          rawVideoPath: result.rawVideoPath
        };

        job.outputs.push(output);
        progressByItem[index] = 100;
        processedEventsByItem[index] = traceEventCount;
        itemStatus.status = "completed";
        itemStatus.progress = 100;
        itemStatus.processedEvents = traceEventCount;
        itemStatus.outputPath = result.outputPath;
        job.logs.push(`Completed ${label}.`);
        await updateOverallProgress("replaying", label);
      } catch (error) {
        const cancelled = error.message === RENDER_CANCELLED_MESSAGE || control.cancelRequested;
        itemStatus.status = cancelled ? "cancelled" : "failed";
        itemStatus.error = cancelled ? null : error.message;
        progressByItem[index] = cancelled ? progressByItem[index] || 0 : 100;
        processedEventsByItem[index] = cancelled ? processedEventsByItem[index] || 0 : traceEventCount;

        if (!cancelled) {
          job.errors.push({
            name: item.name || "",
            link: item.link,
            error: error.message
          });
          job.logs.push(`Failed ${label}: ${error.stack || error.message}`);
        } else {
          job.logs.push(`Cancelled ${label}.`);
        }

        await updateOverallProgress(cancelled ? "canceling" : "failed", label);
      }
    };

    const worker = async () => {
      while (nextCursor < remainingIndexes.length) {
        if (control.cancelRequested) {
          break;
        }

        await waitIfPaused();
        const index = remainingIndexes[nextCursor];
        nextCursor += 1;
        await renderItem(items[index], index);
      }
    };

    await updateOverallProgress("preparing", "");
    await Promise.all(Array.from({ length: Math.min(job.concurrency || 1, remainingIndexes.length || 1) }, worker));

    if (control.cancelRequested) {
      for (const item of job.itemStatuses) {
        if (item.status === "queued") {
          item.status = "cancelled";
        }
      }
      job.status = "cancelled";
      job.error = null;
      job.logs.push("Job cancelled by user.");
    } else {
      job.status = job.errors.length ? "completed_with_errors" : "completed";
      job.error = job.errors.length
        ? `${job.errors.length} render${job.errors.length === 1 ? "" : "s"} failed. Open logs for details.`
        : null;
    }

    const finalCounts = countItemStatuses(job.itemStatuses);
    job.progress = {
      ...(job.progress || {}),
      percent: 100,
      stage: job.status,
      etaMs: 0,
      currentLink: totalItems,
      totalLinks: totalItems,
      activeLinks: 0,
      completedLinks: finalCounts.completed,
      failedLinks: finalCounts.failed,
      cancelledLinks: finalCounts.cancelled,
      queuedLinks: finalCounts.queued,
      processedEvents: Math.max(
        processedEventsByItem.reduce((sum, value) => sum + value, 0),
        traceEventCount * (finalCounts.completed + finalCounts.failed)
      ),
      totalEvents: traceEventCount * totalItems
    };
    await updateJob(job);
  } catch (error) {
    const job = activeJobs.get(jobId) || (await readJob(jobId));
    job.status = control.cancelRequested ? "cancelled" : "failed";
    job.error = control.cancelRequested ? null : error.message;
    job.progress = {
      ...(job.progress || {}),
      stage: job.status,
      etaMs: null,
      activeLinks: 0
    };
    job.logs = job.logs || [];
    job.logs.push(error.stack || error.message);
    await updateJob(job);
  } finally {
    activeRunners.delete(jobId);
    control.paused = false;
    control.cancelRequested = false;
    wakeJobControl(control);
  }
}

function startJobRunner(jobId, options = {}) {
  runRenderJob(jobId, options).catch((error) => {
    console.error(error);
  });
}

app.get("/api/health", async (_request, response) => {
  await ensureDataDirectories();
  response.json({ ok: true });
});

app.get("/api/config", async (_request, response) => {
  await ensureDataDirectories();
  response.json({
    outputDirectory: paths.outputs,
    maxRenderConcurrency
  });
});

app.post("/api/select-output-directory", async (_request, response) => {
  try {
    const directory = await chooseOutputDirectory();
    response.json({
      ok: true,
      directory
    });
  } catch (error) {
    if (/User canceled|cancelled|canceled/i.test(error.message || "")) {
      response.json({
        ok: false,
        cancelled: true
      });
      return;
    }

    response.status(400).json({
      ok: false,
      error: error.message
    });
  }
});

app.get("/api/traces", async (_request, response) => {
  response.json({ traces: await listTraces() });
});

app.get("/api/traces/:id", async (request, response) => {
  try {
    const trace = await getTrace(request.params.id);
    response.json({
      trace,
      summary: summarizeTrace(trace)
    });
  } catch (error) {
    response.status(404).json({ error: error.message });
  }
});

app.post("/api/import-trace", upload.single("file"), async (request, response) => {
  try {
    const payload =
      request.file?.buffer?.length
        ? JSON.parse(request.file.buffer.toString("utf8"))
        : request.body.trace || request.body;

    const trace = await saveTrace(normalizeTrace(payload));
    response.json({
      ok: true,
      trace: summarizeTrace(trace)
    });
  } catch (error) {
    response.status(400).json({
      ok: false,
      error: error.message
    });
  }
});

app.post("/api/upload-audio", upload.single("file"), async (request, response) => {
  try {
    if (!request.file?.buffer?.length) {
      response.status(400).json({ ok: false, error: "No audio file uploaded." });
      return;
    }

    await ensureDataDirectories();

    const originalName = request.file.originalname || "voiceover";
    const extension = path.extname(originalName) || ".bin";
    const safeBaseName = path
      .basename(originalName, extension)
      .replace(/[^a-zA-Z0-9._-]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 60) || "voiceover";
    const fileName = `${Date.now()}-${safeBaseName}${extension}`;
    const filePath = path.join(paths.uploads, fileName);

    await writeFile(filePath, request.file.buffer);

    response.json({
      ok: true,
      audio: {
        fileName,
        originalName,
        size: request.file.size,
        filePath,
        url: `/uploads/${fileName}`
      }
    });
  } catch (error) {
    response.status(400).json({
      ok: false,
      error: error.message
    });
  }
});

app.get("/api/jobs", async (_request, response) => {
  const jobs = await listJobs();
  response.json({
    jobs: jobs.map(buildJobSummary)
  });
});

app.get("/debug/auth-check", (request, response) => {
  const localKeys = String(request.query.local || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
  const sessionKeys = String(request.query.session || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
  const cookieKeys = String(request.query.cookie || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);

  response.type("html").send(`<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Auth Check</title>
  </head>
  <body style="font-family: ui-monospace, monospace; background: #111; color: #eee; padding: 24px;">
    <pre id="output">loading...</pre>
    <script>
      const parseCookies = () => Object.fromEntries(
        document.cookie
          .split(';')
          .map((chunk) => chunk.trim())
          .filter(Boolean)
          .map((chunk) => {
            const index = chunk.indexOf('=');
            return [chunk.slice(0, index), chunk.slice(index + 1)];
          })
      );

      const localKeys = ${JSON.stringify(localKeys)};
      const sessionKeys = ${JSON.stringify(sessionKeys)};
      const cookieKeys = ${JSON.stringify(cookieKeys)};
      const cookies = parseCookies();
      const result = {
        origin: location.origin,
        localStorage: Object.fromEntries(localKeys.map((key) => [key, window.localStorage.getItem(key)])),
        sessionStorage: Object.fromEntries(sessionKeys.map((key) => [key, window.sessionStorage.getItem(key)])),
        cookies: Object.fromEntries(cookieKeys.map((key) => [key, cookies[key] ?? null]))
      };
      window.__dgAuthCheck = result;
      document.getElementById('output').textContent = JSON.stringify(result, null, 2);
    </script>
  </body>
</html>`);
});

app.get("/api/jobs/:id", async (request, response) => {
  try {
    const job = await readJob(request.params.id);
    response.json({ job });
  } catch (error) {
    response.status(404).json({ error: error.message });
  }
});

app.post("/api/render", async (request, response) => {
  const {
    traceId,
    links,
    items,
    audioPath = "",
    speedMultiplier = 1,
    auth = null,
    startDelaySeconds = 0,
    outputDirectory = "",
    concurrency = 1
  } = request.body;
  const batchItems = normalizeBatchItems({ items, links });

  if (!traceId || !batchItems.length) {
    response.status(400).json({
      error: "traceId and at least one render item are required."
    });
    return;
  }

  const job = {
    id: `job-${randomUUID()}`,
    traceId,
    items: batchItems,
    links: batchItems.map((item) => item.link),
    audioPath: audioPath ? path.resolve(audioPath) : null,
    speedMultiplier: Number(speedMultiplier) || 1,
    startDelaySeconds: Math.max(0, Number(startDelaySeconds) || 0),
    outputDirectory: outputDirectory ? path.resolve(String(outputDirectory)) : paths.outputs,
    concurrency: clampConcurrency(concurrency),
    auth:
      auth && auth.type
        ? {
            type: String(auth.type),
            entries: Array.isArray(auth.entries)
              ? auth.entries
                  .map((entry) => ({
                    key: String(entry?.key || "").trim(),
                    value: String(entry?.value ?? "")
                  }))
                  .filter((entry) => entry.key && entry.value !== "")
              : auth.key && auth.token
                ? [{ key: String(auth.key).trim(), value: String(auth.token) }]
                : []
          }
        : null,
    status: "queued",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    outputs: [],
    progress: {
      percent: 0,
      stage: "queued",
      etaMs: null,
      currentLink: 0,
      totalLinks: batchItems.length,
      activeLinks: 0,
      completedLinks: 0,
      processedEvents: 0,
      totalEvents: 0
    },
    logs: []
  };

  await updateJob(job);
  startJobRunner(job.id);

  response.json({
    ok: true,
    job: buildJobSummary(job)
  });
});

app.post("/api/jobs/:id/pause", async (request, response) => {
  try {
    const job = activeJobs.get(request.params.id) || (await readJob(request.params.id));

    if (isTerminalStatus(job.status)) {
      response.status(400).json({ error: "Completed jobs cannot be paused." });
      return;
    }

    const control = getJobControl(job.id);
    control.paused = true;
    job.status = "paused";
    job.progress = {
      ...(job.progress || {}),
      stage: "paused",
      etaMs: null
    };
    job.logs = job.logs || [];
    job.logs.push("Pause requested by user.");
    await updateJob(job);

    response.json({ ok: true, job: buildJobSummary(job) });
  } catch (error) {
    response.status(404).json({ error: error.message });
  }
});

app.post("/api/jobs/:id/resume", async (request, response) => {
  try {
    const job = activeJobs.get(request.params.id) || (await readJob(request.params.id));

    if (isTerminalStatus(job.status)) {
      response.status(400).json({ error: "Completed jobs cannot be resumed." });
      return;
    }

    const control = getJobControl(job.id);
    control.paused = false;
    control.cancelRequested = false;
    wakeJobControl(control);

    job.status = "running";
    job.progress = {
      ...(job.progress || {}),
      stage: "resuming"
    };
    job.logs = job.logs || [];
    job.logs.push("Resume requested by user.");
    await updateJob(job);

    if (!activeRunners.has(job.id)) {
      startJobRunner(job.id, { resume: true });
    }

    response.json({ ok: true, job: buildJobSummary(job) });
  } catch (error) {
    response.status(404).json({ error: error.message });
  }
});

app.post("/api/jobs/:id/cancel", async (request, response) => {
  try {
    const job = activeJobs.get(request.params.id) || (await readJob(request.params.id));

    if (isTerminalStatus(job.status)) {
      response.status(400).json({ error: "Completed jobs cannot be cancelled." });
      return;
    }

    const control = getJobControl(job.id);
    control.cancelRequested = true;
    control.paused = false;
    wakeJobControl(control);

    job.status = activeRunners.has(job.id) ? "canceling" : "cancelled";
    job.progress = {
      ...(job.progress || {}),
      stage: job.status,
      etaMs: null
    };
    job.logs = job.logs || [];
    job.logs.push("Cancel requested by user.");
    await updateJob(job);

    response.json({ ok: true, job: buildJobSummary(job) });
  } catch (error) {
    response.status(404).json({ error: error.message });
  }
});

app.get("/api/jobs/:id/outputs/:index/download", async (request, response) => {
  try {
    const job = await readJob(request.params.id);
    const output = job.outputs?.[Number(request.params.index)];

    if (!output?.outputPath) {
      response.status(404).json({ error: "Output not found." });
      return;
    }

    response.download(output.outputPath, path.basename(output.outputPath));
  } catch (error) {
    response.status(404).json({ error: error.message });
  }
});

app.get("*", (_request, response) => {
  response.sendFile(path.join(paths.uiDist, "index.html"));
});

async function recoverInterruptedJobs() {
  const jobs = await listJobs();

  for (const job of jobs) {
    if (!["queued", "running", "paused", "canceling"].includes(job.status)) {
      continue;
    }

    const items = normalizeBatchItems({ items: job.items, links: job.links });
    job.items = items;
    job.links = items.map((item) => item.link);
    job.itemStatuses = Array.isArray(job.itemStatuses) && job.itemStatuses.length
      ? job.itemStatuses.map((item) => ({
          ...item,
          status: item.status === "running" ? "queued" : item.status
        }))
      : createInitialItemStatuses(items);
    job.status = "paused";
    job.progress = {
      ...(job.progress || {}),
      stage: "paused",
      etaMs: null,
      activeLinks: 0
    };
    job.logs = job.logs || [];
    job.logs.push("Local player restarted while this job was active. Resume to continue or cancel it.");
    await updateJob(job);
  }
}

ensureDataDirectories().then(async () => {
  await recoverInterruptedJobs();
  app.listen(port, () => {
    console.log(`Demo Guilds player running at http://127.0.0.1:${port}`);
  });
});
