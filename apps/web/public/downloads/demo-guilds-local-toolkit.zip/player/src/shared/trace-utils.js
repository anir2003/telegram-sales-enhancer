export function normalizeTrace(input) {
  if (!input || typeof input !== "object") {
    throw new Error("Trace payload must be an object.");
  }

  const trace = structuredClone(input);
  trace.version = trace.version || 1;
  trace.id = trace.id || `trace-${Date.now()}`;
  trace.name = trace.name || trace.id;
  trace.startedAt = Number(trace.startedAt || Date.now());
  trace.endedAt = Number(trace.endedAt || trace.startedAt);
  trace.meta = trace.meta || {};
  trace.events = Array.isArray(trace.events) ? trace.events : [];
  trace.tabs = trace.tabs || {};

  trace.events = trace.events
    .filter(Boolean)
    .map((event, index) => ({
      at: Number(event.at || trace.startedAt + index),
      ...event
    }))
    .sort((a, b) => a.at - b.at);

  if (!trace.meta.initialUrl) {
    trace.meta.initialUrl = trace.events.find((event) => event.url)?.url || null;
  }

  if (!trace.meta.sourceViewport) {
    trace.meta.sourceViewport =
      trace.events.find((event) => event.viewport)?.viewport || {
        width: 1440,
        height: 900,
        devicePixelRatio: 1,
        scrollX: 0,
        scrollY: 0
      };
  }

  return trace;
}

export function summarizeTrace(trace) {
  const normalized = normalizeTrace(trace);
  const eventCounts = normalized.events.reduce((accumulator, event) => {
    accumulator[event.type] = (accumulator[event.type] || 0) + 1;
    return accumulator;
  }, {});

  const lastEvent = normalized.events[normalized.events.length - 1];

  return {
    id: normalized.id,
    name: normalized.name,
    startedAt: normalized.startedAt,
    endedAt: normalized.endedAt,
    durationMs: Math.max(0, (lastEvent?.at || normalized.endedAt) - normalized.startedAt),
    initialUrl: normalized.meta.initialUrl,
    viewport: normalized.meta.sourceViewport,
    eventCount: normalized.events.length,
    eventCounts
  };
}

export function getRenderableEvents(trace) {
  return normalizeTrace(trace).events.filter((event) =>
    [
      "POINTER_MOVE",
      "POINTER_DOWN",
      "POINTER_UP",
      "CLICK",
      "DOUBLE_CLICK",
      "WHEEL",
      "SCROLL",
      "KEY_DOWN",
      "KEY_UP",
      "INPUT",
      "CHANGE",
      "TAB_ACTIVATED",
      "URL_CHANGED",
      "NAVIGATION_COMMITTED"
    ].includes(event.type)
  );
}

export function sanitizeFilename(value) {
  return String(value || "output")
    .replace(/https?:\/\//g, "")
    .replace(/[^a-zA-Z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80) || "output";
}

export function createTraceVariant(trace, targetUrl) {
  const normalized = normalizeTrace(trace);
  const sourceUrl = normalized.meta.initialUrl;

  if (!sourceUrl || !targetUrl) {
    return normalized;
  }

  let source;
  let target;

  try {
    source = new URL(sourceUrl);
    target = new URL(targetUrl);
  } catch {
    return normalized;
  }

  const sourceSegments = source.pathname.split("/");
  const targetSegments = target.pathname.split("/");
  const changedIndexes = [];

  for (let index = 0; index < Math.min(sourceSegments.length, targetSegments.length); index += 1) {
    if (sourceSegments[index] !== targetSegments[index]) {
      changedIndexes.push(index);
    }
  }

  const queryReplacements = [];
  for (const [key, value] of source.searchParams.entries()) {
    const nextValue = target.searchParams.get(key);
    if (nextValue !== null && nextValue !== value) {
      queryReplacements.push([key, nextValue]);
    }
  }

  const remapUrl = (inputUrl) => {
    if (!inputUrl) {
      return inputUrl;
    }

    let current;
    try {
      current = new URL(inputUrl);
    } catch {
      return inputUrl;
    }

    if (current.origin !== source.origin) {
      return inputUrl;
    }

    const segments = current.pathname.split("/");
    for (const index of changedIndexes) {
      if (segments[index] === sourceSegments[index]) {
        segments[index] = targetSegments[index];
      }
    }

    current.pathname = segments.join("/");

    for (const [key, value] of queryReplacements) {
      if (current.searchParams.get(key) === source.searchParams.get(key)) {
        current.searchParams.set(key, value);
      }
    }

    if (inputUrl === sourceUrl) {
      return targetUrl;
    }

    return current.toString();
  };

  normalized.meta.targetUrl = targetUrl;
  normalized.events = normalized.events.map((event) => ({
    ...event,
    url: remapUrl(event.url)
  }));

  return normalized;
}
