import path from "node:path";

import { renderTraceToVideo } from "./render.js";
import { getTrace } from "./storage.js";

function parseArguments(argv) {
  const options = {
    trace: null,
    links: [],
    audio: null,
    speed: 1
  };

  for (let index = 0; index < argv.length; index += 1) {
    const value = argv[index];
    const next = argv[index + 1];

    if (value === "--trace") {
      options.trace = next;
      index += 1;
    } else if (value === "--links") {
      options.links = String(next || "")
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);
      index += 1;
    } else if (value === "--audio") {
      options.audio = next ? path.resolve(next) : null;
      index += 1;
    } else if (value === "--speed") {
      options.speed = Number(next || "1") || 1;
      index += 1;
    }
  }

  return options;
}

async function main() {
  const options = parseArguments(process.argv.slice(2));

  if (!options.trace || !options.links.length) {
    console.error("Usage: npm run render -- --trace TRACE_ID_OR_PATH --links https://one,https://two [--audio /abs/path.mp3] [--speed 1]");
    process.exitCode = 1;
    return;
  }

  const trace = await getTrace(options.trace);

  for (const link of options.links) {
    const result = await renderTraceToVideo(trace, {
      targetUrl: link,
      audioPath: options.audio,
      speedMultiplier: options.speed
    });

    console.log(`Rendered ${link} -> ${result.outputPath}`);
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
