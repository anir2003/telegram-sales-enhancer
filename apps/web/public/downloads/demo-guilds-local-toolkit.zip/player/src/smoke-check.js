import { ensureDataDirectories, listJobs, listTraces } from "./storage.js";

async function main() {
  await ensureDataDirectories();
  const [traces, jobs] = await Promise.all([listTraces(), listJobs()]);
  console.log(`Smoke check OK. Traces: ${traces.length}. Jobs: ${jobs.length}.`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
