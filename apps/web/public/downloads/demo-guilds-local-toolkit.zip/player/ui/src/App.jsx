import { useEffect, useMemo, useRef, useState } from "react";
import {
  Plus,
  ChevronDown,
  Download,
  FileSpreadsheet,
  FileUp,
  FolderOpen,
  ListVideo,
  Monitor,
  Moon,
  Pause,
  Play,
  RefreshCw,
  RotateCcw,
  UploadCloud,
  Trash2,
  Terminal,
  Shield,
  Sun,
  Video
} from "lucide-react";

import { useTheme } from "@/hooks/use-theme";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";

function cn(...classes) {
  return classes.filter(Boolean).join(" ");
}

function formatDuration(ms) {
  return `${(ms / 1000).toFixed(1)}s`;
}

function formatDate(value) {
  return new Date(value).toLocaleString();
}

function statusVariant(status) {
  switch (status) {
    case "completed":
      return "success";
    case "completed_with_errors":
      return "destructive";
    case "failed":
      return "destructive";
    case "cancelled":
      return "destructive";
    case "running":
      return "default";
    case "paused":
      return "secondary";
    default:
      return "secondary";
  }
}

function formatEta(ms) {
  if (ms === null || ms === undefined) {
    return "Calculating…";
  }

  const totalSeconds = Math.max(0, Math.round(ms / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  if (minutes > 0) {
    return `${minutes}m ${String(seconds).padStart(2, "0")}s left`;
  }

  return `${seconds}s left`;
}

function formatPercent(value) {
  const numeric = Number(value || 0);
  return numeric >= 10 ? `${Math.round(numeric)}%` : `${numeric.toFixed(1)}%`;
}

function labelForStage(stage) {
  switch (stage) {
    case "queued":
      return "Queued";
    case "paused":
      return "Paused";
    case "resuming":
      return "Resuming";
    case "canceling":
      return "Cancelling";
    case "cancelled":
      return "Cancelled";
    case "preparing":
      return "Preparing browser";
    case "waiting":
      return "Waiting to start";
    case "replaying":
      return "Replaying trace";
    case "finishing":
      return "Finalizing capture";
    case "encoding":
      return "Encoding video";
    case "completed":
      return "Completed";
    case "completed_with_errors":
      return "Completed with errors";
    case "failed":
      return "Failed";
    default:
      return "Working";
  }
}

function outputHref(jobId, outputIndex) {
  if (!jobId || outputIndex === undefined || outputIndex === null) {
    return null;
  }

  return `/api/jobs/${jobId}/outputs/${outputIndex}/download`;
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let value = "";
  let inQuotes = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];

    if (char === '"' && inQuotes && next === '"') {
      value += '"';
      index += 1;
      continue;
    }

    if (char === '"') {
      inQuotes = !inQuotes;
      continue;
    }

    if (char === "," && !inQuotes) {
      row.push(value.trim());
      value = "";
      continue;
    }

    if ((char === "\n" || char === "\r") && !inQuotes) {
      if (char === "\r" && next === "\n") {
        index += 1;
      }
      row.push(value.trim());
      if (row.some(Boolean)) {
        rows.push(row);
      }
      row = [];
      value = "";
      continue;
    }

    value += char;
  }

  row.push(value.trim());
  if (row.some(Boolean)) {
    rows.push(row);
  }

  return rows;
}

function parseCsvBatch(text) {
  const rows = parseCsv(text);
  if (!rows.length) {
    return [];
  }

  const headers = rows[0].map((header) => header.toLowerCase().trim());
  const nameIndex = headers.findIndex((header) => ["name", "company", "company name", "account"].includes(header));
  const linkIndex = headers.findIndex((header) => ["link", "url", "demo link", "website"].includes(header));
  const hasHeaders = nameIndex !== -1 || linkIndex !== -1;
  const fallbackLinkIndex = linkIndex !== -1 ? linkIndex : rows[0].findIndex((cell) => /^https?:\/\//i.test(cell));
  const finalNameIndex = nameIndex !== -1 ? nameIndex : fallbackLinkIndex === 0 ? 1 : 0;
  const finalLinkIndex = fallbackLinkIndex !== -1 ? fallbackLinkIndex : 1;

  return rows
    .slice(hasHeaders ? 1 : 0)
    .map((row, index) => ({
      id: crypto.randomUUID?.() || `row-${Date.now()}-${index}`,
      name: String(row[finalNameIndex] || "").trim(),
      link: String(row[finalLinkIndex] || "").trim()
    }))
    .filter((row) => row.link);
}

function parseManualRenderItems(value) {
  return value
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line, index) => {
      const tabParts = line.split("\t").map((part) => part.trim()).filter(Boolean);
      const commaParts = line.split(",").map((part) => part.trim()).filter(Boolean);
      const parts = tabParts.length >= 2 ? tabParts : commaParts.length >= 2 ? commaParts : [];

      if (parts.length >= 2) {
        const linkIndex = parts.findIndex((part) => /^https?:\/\//i.test(part));
        if (linkIndex !== -1) {
          return {
            id: `manual-${index}`,
            name: parts.filter((_, partIndex) => partIndex !== linkIndex).join(" ").trim(),
            link: parts[linkIndex]
          };
        }
      }

      return {
        id: `manual-${index}`,
        name: "",
        link: line
      };
    })
    .filter((row) => row.link);
}

function importantEvents(trace) {
  return trace?.events?.filter((event) =>
    ["CLICK", "DOUBLE_CLICK", "SCROLL", "INPUT", "KEY_DOWN", "TAB_ACTIVATED", "URL_CHANGED", "NAVIGATION_COMMITTED"].includes(event.type)
  ) || [];
}

function summarize(trace) {
  const stats = { clicks: 0, keys: 0, scrolls: 0, navigations: 0 };
  for (const event of trace?.events || []) {
    if (event.type === "CLICK" || event.type === "DOUBLE_CLICK") {
      stats.clicks += 1;
    }
    if (event.type === "KEY_DOWN") {
      stats.keys += 1;
    }
    if (event.type === "SCROLL" || event.type === "WHEEL") {
      stats.scrolls += 1;
    }
    if (event.type === "TAB_ACTIVATED" || event.type === "URL_CHANGED" || event.type === "NAVIGATION_COMMITTED") {
      stats.navigations += 1;
    }
  }
  return stats;
}

function keycaps(trace) {
  return (trace?.events || [])
    .filter((event) => event.type === "KEY_DOWN")
    .map((event) => event.printable || event.key)
    .filter(Boolean)
    .slice(-24);
}

function labelForEvent(event) {
  switch (event.type) {
    case "INPUT":
      return `Typed ${event.value ? `"${event.value}"` : "into a field"}`;
    case "KEY_DOWN":
      return `Pressed ${event.printable || event.key}`;
    case "SCROLL":
      return `Scrolled to ${event.pageScrollY || event.scrollTop || 0}px`;
    case "CLICK":
      return `Clicked ${event.target?.text || event.target?.tagName || "element"}`;
    case "DOUBLE_CLICK":
      return `Double-clicked ${event.target?.text || event.target?.tagName || "element"}`;
    case "TAB_ACTIVATED":
      return "Changed tab";
    case "URL_CHANGED":
    case "NAVIGATION_COMMITTED":
      return "Navigated";
    default:
      return event.type;
  }
}

const AUTH_PRESETS_STORAGE_KEY = "dg-auth-presets";

async function fetchJson(url, options = {}) {
  const response = await fetch(url, options);
  const body = await response.json();
  if (!response.ok) {
    throw new Error(body.error || `Request failed (${response.status})`);
  }
  return body;
}

function SidebarSection({ title, items, activeValue, onSelect }) {
  return (
    <div className="space-y-2">
      <p className="px-2 text-[11px] uppercase tracking-[0.22em] text-muted-foreground">{title}</p>
      <div className="space-y-1">
        {items.map((item) => (
          <button
            key={item.label}
            type="button"
            onClick={() => item.id && onSelect?.(item.id)}
            className={cn(
              "flex w-full items-center justify-between rounded-md px-2 py-2 text-left text-sm transition hover:bg-accent/60 hover:text-foreground",
              activeValue === item.id ? "bg-accent text-foreground" : "text-muted-foreground"
            )}
          >
            <span>{item.label}</span>
            {item.value ? <span className="text-xs text-muted-foreground">{item.value}</span> : null}
          </button>
        ))}
      </div>
    </div>
  );
}

function JobProgress({ job }) {
  const progress = Math.max(0, Math.min(100, Number(job.progress?.percent || (job.status === "completed" ? 100 : 0))));
  const stageLabel = labelForStage(job.progress?.stage || job.status);
  const currentLink = Number(job.progress?.currentLink || 0);
  const totalLinks = Number(job.progress?.totalLinks || job.linkCount || 0);
  const activeLinks = Number(job.progress?.activeLinks || 0);
  const completedLinks = Number(job.progress?.completedLinks || 0);
  const failedLinks = Number(job.progress?.failedLinks || 0);
  const cancelledLinks = Number(job.progress?.cancelledLinks || 0);
  const queuedLinks = Number(job.progress?.queuedLinks || 0);
  const processedEvents = Number(job.progress?.processedEvents || 0);
  const totalEvents = Number(job.progress?.totalEvents || 0);

  return (
    <div className="mt-3 space-y-2">
      <div className="flex items-center justify-between gap-3 text-xs text-muted-foreground">
        <span>{stageLabel}</span>
        <span>{formatPercent(progress)}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full border border-border/80 bg-background/80">
        <div
          className={cn(
            "h-full transition-all",
            job.status === "failed" ? "bg-destructive" : job.status === "completed" ? "bg-emerald-500" : "bg-primary"
          )}
          style={{ width: `${progress}%` }}
        />
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-muted-foreground">
        <span>
          {totalLinks
            ? `${completedLinks} done${failedLinks ? `, ${failedLinks} failed` : ""}${cancelledLinks ? `, ${cancelledLinks} cancelled` : ""}${activeLinks ? `, ${activeLinks} active` : ""}${queuedLinks ? `, ${queuedLinks} queued` : ""} of ${totalLinks}`
            : currentLink
              ? `Link ${currentLink}`
              : "Waiting for work"}
        </span>
        <span>{job.status === "running" || job.status === "queued" ? formatEta(job.progress?.etaMs) : stageLabel}</span>
      </div>
      {totalEvents ? (
        <p className="text-[11px] text-muted-foreground">
          {Math.min(processedEvents, totalEvents)} / {totalEvents} events processed
        </p>
      ) : null}
    </div>
  );
}

export default function App() {
  const { theme, toggleTheme } = useTheme();
  const [traces, setTraces] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [activeFolder, setActiveFolder] = useState("recordings");
  const [selectedTraceId, setSelectedTraceId] = useState(null);
  const [selectedTrace, setSelectedTrace] = useState(null);
  const [selectedSummary, setSelectedSummary] = useState(null);
  const [renderLinks, setRenderLinks] = useState("");
  const [batchRows, setBatchRows] = useState([]);
  const [batchUploadStatus, setBatchUploadStatus] = useState("");
  const [isCsvDragActive, setIsCsvDragActive] = useState(false);
  const [outputDirectory, setOutputDirectory] = useState("");
  const [isChoosingOutputDirectory, setIsChoosingOutputDirectory] = useState(false);
  const [concurrency, setConcurrency] = useState("1");
  const [maxRenderConcurrency, setMaxRenderConcurrency] = useState(2);
  const [audioPath, setAudioPath] = useState("");
  const [uploadedAudio, setUploadedAudio] = useState(null);
  const [audioUploadStatus, setAudioUploadStatus] = useState("");
  const [isAudioDragActive, setIsAudioDragActive] = useState(false);
  const [speedMultiplier, setSpeedMultiplier] = useState("1");
  const [startDelaySeconds, setStartDelaySeconds] = useState("0");
  const [authType, setAuthType] = useState("none");
  const [authEntries, setAuthEntries] = useState([{ id: crypto.randomUUID(), key: "airaa-token", value: "" }]);
  const [authPresets, setAuthPresets] = useState([]);
  const [presetName, setPresetName] = useState("");
  const [importStatus, setImportStatus] = useState("");
  const [renderStatus, setRenderStatus] = useState("");
  const [previewProgress, setPreviewProgress] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [previewMessage, setPreviewMessage] = useState("Ready to preview");
  const [overlayKey, setOverlayKey] = useState("");
  const [showActivity, setShowActivity] = useState(false);
  const [showLogs, setShowLogs] = useState({});
  const [showAuthSettings, setShowAuthSettings] = useState(false);
  const [showAudioSettings, setShowAudioSettings] = useState(false);
  const fileRef = useRef(null);
  const csvFileRef = useRef(null);
  const audioFileRef = useRef(null);
  const animationRef = useRef(null);
  const animationStartRef = useRef(0);
  const baseProgressRef = useRef(0);

  const stats = useMemo(() => summarize(selectedTrace), [selectedTrace]);
  const keys = useMemo(() => keycaps(selectedTrace), [selectedTrace]);
  const events = useMemo(() => importantEvents(selectedTrace).slice(0, 60), [selectedTrace]);
  const renderItems = useMemo(
    () => (batchRows.length ? batchRows : parseManualRenderItems(renderLinks)),
    [batchRows, renderLinks]
  );

  useEffect(() => {
    loadTraces();
    loadJobs();
    loadConfig();
    const intervalId = window.setInterval(loadJobs, 1500);
    return () => window.clearInterval(intervalId);
  }, []);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(AUTH_PRESETS_STORAGE_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      setAuthPresets(Array.isArray(parsed) ? parsed : []);
    } catch {
      setAuthPresets([]);
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem(AUTH_PRESETS_STORAGE_KEY, JSON.stringify(authPresets));
  }, [authPresets]);

  useEffect(() => {
    if (!selectedTrace) {
      setPreviewMessage("Ready to preview");
      setOverlayKey("");
    }
  }, [selectedTrace]);

  useEffect(() => {
    if (!isPlaying || !selectedTrace?.events?.length) {
      return;
    }

    const firstAt = selectedTrace.events[0].at;
    const lastAt = selectedTrace.events[selectedTrace.events.length - 1].at;
    const duration = Math.max(1, lastAt - firstAt);
    animationStartRef.current = performance.now();
    baseProgressRef.current = previewProgress;

    const tick = (now) => {
      const delta = (now - animationStartRef.current) / duration;
      const nextProgress = Math.min(1, baseProgressRef.current + delta);
      setPreviewProgress(nextProgress);

      if (nextProgress >= 1) {
        setIsPlaying(false);
        return;
      }

      animationRef.current = requestAnimationFrame(tick);
    };

    animationRef.current = requestAnimationFrame(tick);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    };
  }, [isPlaying, previewProgress, selectedTrace]);

  useEffect(() => {
    if (!selectedTrace?.events?.length) {
      return;
    }

    const firstAt = selectedTrace.events[0].at;
    const lastAt = selectedTrace.events[selectedTrace.events.length - 1].at;
    const currentAt = firstAt + (lastAt - firstAt) * previewProgress;
    const visibleEvents = selectedTrace.events.filter((event) => event.at <= currentAt);
    const latest = [...visibleEvents].reverse().find((event) =>
      ["INPUT", "KEY_DOWN", "CLICK", "DOUBLE_CLICK", "SCROLL", "TAB_ACTIVATED", "URL_CHANGED", "NAVIGATION_COMMITTED"].includes(event.type)
    );

    if (!latest) {
      setPreviewMessage("Ready to preview");
      setOverlayKey("");
      return;
    }

    setPreviewMessage(labelForEvent(latest));

    if (latest.type === "KEY_DOWN") {
      setOverlayKey(latest.printable || latest.key);
    } else if (latest.type === "INPUT") {
      setOverlayKey((latest.value || "").slice(-18));
    } else {
      setOverlayKey("");
    }
  }, [previewProgress, selectedTrace]);

  async function loadConfig() {
    try {
      const response = await fetchJson("/api/config");
      setOutputDirectory(response.outputDirectory || "");
      setMaxRenderConcurrency(Number(response.maxRenderConcurrency || 2));
      setConcurrency((current) => String(Math.min(Number(current || 1), Number(response.maxRenderConcurrency || 2))));
    } catch {
      setOutputDirectory("");
    }
  }

  async function loadTraces() {
    const response = await fetchJson("/api/traces");
    setTraces(response.traces);
  }

  async function loadJobs() {
    const response = await fetchJson("/api/jobs");
    setJobs(response.jobs);
  }

  async function loadTrace(traceId) {
    const response = await fetchJson(`/api/traces/${traceId}`);
    setSelectedTraceId(traceId);
    setSelectedTrace(response.trace);
    setSelectedSummary(response.summary);
    setPreviewProgress(0);
    setIsPlaying(false);
  }

  async function handleImport(event) {
    event.preventDefault();
    setImportStatus("Uploading trace…");
    try {
      const formData = new FormData();
      if (fileRef.current?.files?.[0]) {
        formData.append("file", fileRef.current.files[0]);
      }

      await fetchJson("/api/import-trace", {
        method: "POST",
        body: formData
      });

      setImportStatus("Trace uploaded.");
      if (fileRef.current) {
        fileRef.current.value = "";
      }
      await loadTraces();
    } catch (error) {
      setImportStatus(error.message);
    }
  }

  async function uploadBatchCsv(file) {
    if (!file) {
      return;
    }

    setBatchUploadStatus("Reading CSV…");
    try {
      const text = await file.text();
      const rows = parseCsvBatch(text);
      if (!rows.length) {
        setBatchUploadStatus("No rows found. Use columns named Name/Company and Link/URL.");
        return;
      }

      setBatchRows(rows);
      setRenderLinks(rows.map((row) => `${row.name ? `${row.name}, ` : ""}${row.link}`).join("\n"));
      setBatchUploadStatus(`Loaded ${rows.length} row${rows.length === 1 ? "" : "s"} from ${file.name}.`);
    } catch (error) {
      setBatchUploadStatus(error.message);
    }
  }

  function clearBatchRows() {
    setBatchRows([]);
    setBatchUploadStatus("");
    if (csvFileRef.current) {
      csvFileRef.current.value = "";
    }
  }

  async function chooseOutputDirectory() {
    setIsChoosingOutputDirectory(true);
    setRenderStatus("Opening folder picker…");

    try {
      const response = await fetchJson("/api/select-output-directory", {
        method: "POST"
      });

      if (response.cancelled) {
        setRenderStatus("Folder selection cancelled.");
        return;
      }

      if (response.directory) {
        setOutputDirectory(response.directory);
        setRenderStatus("Export folder selected.");
      }
    } catch (error) {
      setRenderStatus(error.message);
    } finally {
      setIsChoosingOutputDirectory(false);
    }
  }

  async function handleRender(event) {
    event.preventDefault();
    if (!selectedTraceId) {
      setRenderStatus("Select a trace first.");
      return;
    }

    const items = renderItems
      .map((item) => ({
        name: item.name.trim(),
        link: item.link.trim()
      }))
      .filter((item) => item.link);

    if (!items.length) {
      setRenderStatus("Add at least one link or upload a CSV.");
      return;
    }

    const chosenOutputDirectory = outputDirectory.trim();
    if (!chosenOutputDirectory) {
      setRenderStatus("Choose an export folder before rendering.");
      return;
    }

    setRenderStatus("Queueing render job…");

    try {
      await fetchJson("/api/render", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          traceId: selectedTraceId,
          items,
          audioPath: uploadedAudio?.filePath || audioPath.trim(),
          speedMultiplier: Number(speedMultiplier || 1),
          startDelaySeconds: Number(startDelaySeconds || 0),
          outputDirectory: chosenOutputDirectory,
          concurrency: Number(concurrency || 1),
          auth:
            authType !== "none" && authEntries.some((entry) => entry.key.trim() && entry.value !== "")
              ? {
                type: authType,
                entries: authEntries
                  .map((entry) => ({
                    key: entry.key.trim(),
                    value: entry.value
                  }))
                  .filter((entry) => entry.key && entry.value !== "")
              }
            : null
        })
      });

      setRenderStatus("Render job queued.");
      await loadJobs();
    } catch (error) {
      setRenderStatus(error.message);
    }
  }

  async function handleJobAction(jobId, action) {
    setRenderStatus("");
    try {
      await fetchJson(`/api/jobs/${jobId}/${action}`, {
        method: "POST"
      });
      await loadJobs();
    } catch (error) {
      setRenderStatus(error.message);
    }
  }

  function resetPreview() {
    setIsPlaying(false);
    setPreviewProgress(0);
  }

  const viewport = selectedTrace?.meta?.sourceViewport || { width: 1440, height: 900 };
  const currentPoint = useMemo(() => {
    if (!selectedTrace?.events?.length) {
      return null;
    }

    const firstAt = selectedTrace.events[0].at;
    const lastAt = selectedTrace.events[selectedTrace.events.length - 1].at;
    const currentAt = firstAt + (lastAt - firstAt) * previewProgress;
    const lastMove = [...selectedTrace.events].reverse().find(
      (event) => event.at <= currentAt && (typeof event.normalizedX === "number" || typeof event.clientX === "number")
    );

    if (!lastMove) {
      return null;
    }

    return {
      x: typeof lastMove.normalizedX === "number" ? lastMove.normalizedX * viewport.width : lastMove.clientX || 0,
      y: typeof lastMove.normalizedY === "number" ? lastMove.normalizedY * viewport.height : lastMove.clientY || 0
    };
  }, [previewProgress, selectedTrace, viewport.height, viewport.width]);

  const workspaceFolders = [
    { id: "recordings", label: "Recordings", value: `${traces.length}` },
    { id: "render", label: "Render Batch", value: `${renderItems.length}` },
    { id: "jobs", label: "Jobs & Logs", value: `${jobs.length}` }
  ];

  function addAuthEntry() {
    setAuthEntries((current) => [...current, { id: crypto.randomUUID(), key: "", value: "" }]);
  }

  function updateAuthEntry(id, field, nextValue) {
    setAuthEntries((current) => current.map((entry) => (entry.id === id ? { ...entry, [field]: nextValue } : entry)));
  }

  function removeAuthEntry(id) {
    setAuthEntries((current) => (current.length > 1 ? current.filter((entry) => entry.id !== id) : [{ id: crypto.randomUUID(), key: "", value: "" }]));
  }

  function saveAuthPreset() {
    const cleanedEntries = authEntries
      .map((entry) => ({
        key: entry.key.trim(),
        value: entry.value
      }))
      .filter((entry) => entry.key && entry.value !== "");

    if (!presetName.trim() || authType === "none" || !cleanedEntries.length) {
      setRenderStatus("Add a preset name, choose an auth type, and include at least one key/value pair.");
      return;
    }

    const nextPreset = {
      id: crypto.randomUUID(),
      name: presetName.trim(),
      type: authType,
      entries: cleanedEntries
    };

    setAuthPresets((current) => {
      const withoutSameName = current.filter((preset) => preset.name !== nextPreset.name);
      return [nextPreset, ...withoutSameName];
    });
    setRenderStatus(`Saved auth preset "${presetName.trim()}".`);
  }

  function loadAuthPreset(presetId) {
    const preset = authPresets.find((item) => item.id === presetId);
    if (!preset) {
      return;
    }

    setAuthType(preset.type);
    setAuthEntries(
      preset.entries.map((entry) => ({
        id: crypto.randomUUID(),
        key: entry.key,
        value: entry.value
      }))
    );
    setPresetName(preset.name);
    setRenderStatus(`Loaded auth preset "${preset.name}".`);
  }

  function deleteAuthPreset(presetId) {
    setAuthPresets((current) => current.filter((preset) => preset.id !== presetId));
  }

  async function uploadAudioFile(file) {
    if (!file) {
      return;
    }

    setAudioUploadStatus("Uploading voice-over…");
    try {
      const formData = new FormData();
      formData.append("file", file);
      const response = await fetchJson("/api/upload-audio", {
        method: "POST",
        body: formData
      });
      setUploadedAudio(response.audio);
      setAudioPath(response.audio.filePath);
      setAudioUploadStatus(`Uploaded ${response.audio.originalName}.`);
    } catch (error) {
      setAudioUploadStatus(error.message);
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto grid min-h-screen max-w-[1500px] grid-cols-1 xl:grid-cols-[240px_minmax(0,1fr)]">
        <aside className="hidden border-r border-border/80 bg-card/60 xl:block">
          <div className="sticky top-0 flex h-screen flex-col px-5 py-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold">Demo Guilds</p>
                <p className="text-xs text-muted-foreground">Local player</p>
              </div>
              <Button variant="ghost" size="icon" onClick={toggleTheme} className="h-8 w-8">
                {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
            </div>

            <div className="mt-8 space-y-6">
              <SidebarSection title="Folders" items={workspaceFolders} activeValue={activeFolder} onSelect={setActiveFolder} />
              <SidebarSection
                title="Flow"
                items={[
                  { label: "1. Import trace", value: null },
                  { label: "2. Add CSV/links", value: null },
                  { label: "3. Render videos", value: null }
                ]}
              />
            </div>

            <div className="mt-auto rounded-lg border border-border/80 bg-background/70 p-4">
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Endpoint</p>
              <p className="mt-2 break-all font-mono text-xs text-foreground">http://127.0.0.1:4312</p>
            </div>
          </div>
        </aside>

        <main className="min-w-0 px-4 py-4 md:px-6">
          <div className="space-y-4">
            <header className="flex flex-col gap-4 border-b border-border/80 pb-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-[11px] uppercase tracking-[0.24em] text-muted-foreground">Demo player</p>
                <h1 className="mt-1 text-2xl font-semibold tracking-tight">Trace Studio</h1>
                <p className="mt-1 text-sm text-muted-foreground">
                  Record once, replay on new links, and render local MP4s with the recorded viewport.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="rounded-md px-2 py-1">
                  Viewport matched
                </Badge>
                <Button variant="outline" size="icon" onClick={toggleTheme} className="xl:hidden">
                  {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                </Button>
              </div>
            </header>

            <nav className="grid gap-2 sm:grid-cols-3 xl:hidden">
              {workspaceFolders.map((folder) => (
                <Button
                  key={folder.id}
                  type="button"
                  variant={activeFolder === folder.id ? "secondary" : "ghost"}
                  onClick={() => setActiveFolder(folder.id)}
                  className="justify-between rounded-md"
                >
                  <span>{folder.label}</span>
                  <Badge variant="outline" className="rounded-md">{folder.value}</Badge>
                </Button>
              ))}
            </nav>

            {activeFolder === "recordings" ? (
              <>
            <section className="grid gap-4 lg:grid-cols-[320px_minmax(0,1fr)]">
              <Card className="rounded-lg border-border/80 shadow-none">
                <CardHeader className="pb-4">
                  <CardTitle className="text-base">Import Trace</CardTitle>
                  <CardDescription>Upload a JSON trace or use the extension’s send action.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <form className="space-y-3" onSubmit={handleImport}>
                    <Input ref={fileRef} type="file" accept=".json,application/json" className="h-10 rounded-md" />
                    <Button type="submit" className="w-full rounded-md">
                      <FileUp className="h-4 w-4" />
                      Upload
                    </Button>
                  </form>
                  {importStatus ? <p className="text-xs text-muted-foreground">{importStatus}</p> : null}
                </CardContent>
              </Card>

              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {[
                  { label: "Clicks", value: stats.clicks },
                  { label: "Keystrokes", value: stats.keys },
                  { label: "Scrolls", value: stats.scrolls },
                  { label: "Navigations", value: stats.navigations }
                ].map((item) => (
                  <Card key={item.label} className="rounded-lg border-border/80 shadow-none">
                    <CardContent className="p-4">
                      <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">{item.label}</p>
                      <p className="mt-3 text-3xl font-semibold leading-none">{item.value}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            <section className="grid gap-4 xl:grid-cols-[300px_minmax(0,1fr)]">
              <Card className="rounded-lg border-border/80 shadow-none">
                <CardHeader className="flex-row items-start justify-between space-y-0 pb-4">
                  <div>
                    <CardTitle className="text-base">Traces</CardTitle>
                    <CardDescription>Choose a recording to preview.</CardDescription>
                  </div>
                  <Button variant="ghost" size="icon" onClick={loadTraces} className="h-8 w-8 rounded-md">
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </CardHeader>
                <CardContent className="space-y-2">
                  {traces.length ? (
                    traces.map((trace) => (
                      <button
                        key={trace.id}
                        type="button"
                        onClick={() => loadTrace(trace.id)}
                        className={cn(
                          "w-full rounded-md border px-3 py-3 text-left transition",
                          selectedTraceId === trace.id
                            ? "border-primary/50 bg-accent text-foreground"
                            : "border-border/80 bg-background/40 text-foreground hover:bg-accent/60"
                        )}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium">{trace.name}</p>
                            <p className="mt-1 text-xs text-muted-foreground">{trace.eventCount} events</p>
                          </div>
                          <Badge variant="secondary" className="rounded-md">
                            {formatDuration(trace.durationMs)}
                          </Badge>
                        </div>
                        <p className="mt-2 break-all text-xs text-muted-foreground">{trace.initialUrl || "No URL recorded"}</p>
                      </button>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No traces imported yet.</p>
                  )}
                </CardContent>
              </Card>

              <Card className="rounded-lg border-border/80 shadow-none">
                {!selectedTrace ? (
                  <CardContent className="flex min-h-[420px] items-center justify-center p-6 text-sm text-muted-foreground">
                    Select a trace to open the preview.
                  </CardContent>
                ) : (
                  <>
                    <CardHeader className="flex-row items-start justify-between space-y-0 pb-4">
                      <div>
                        <CardTitle className="text-base">{selectedTrace.name}</CardTitle>
                        <CardDescription className="mt-1">
                          {selectedSummary?.eventCount} events • {selectedSummary ? formatDuration(selectedSummary.durationMs) : "0.0s"}
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" onClick={() => setIsPlaying((current) => !current)} className="rounded-md">
                          {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                          {isPlaying ? "Pause" : "Play"}
                        </Button>
                        <Button variant="ghost" onClick={resetPreview} className="rounded-md">
                          <RotateCcw className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      <div className="overflow-hidden rounded-md border border-border/80 bg-[#0a0a0b]">
                        <div className="flex items-center gap-2 border-b border-white/10 px-3 py-2">
                          <span className="h-2.5 w-2.5 rounded-full bg-white/30" />
                          <span className="h-2.5 w-2.5 rounded-full bg-white/20" />
                          <span className="h-2.5 w-2.5 rounded-full bg-white/10" />
                          <p className="ml-2 truncate text-xs text-white/45">{selectedSummary?.initialUrl}</p>
                        </div>
                        <div className="relative aspect-[16/9] bg-[#111112]">
                          <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(255,255,255,0.02),rgba(255,255,255,0))]" />
                          {currentPoint ? (
                            <div
                              className="apple-pointer absolute h-6 w-4 drop-shadow-[0_4px_8px_rgba(0,0,0,0.3)]"
                              style={{
                                left: `${(currentPoint.x / viewport.width) * 100}%`,
                                top: `${(currentPoint.y / viewport.height) * 100}%`,
                                transform: "translate(-1px, -1px)"
                              }}
                            />
                          ) : null}
                          {overlayKey ? (
                            <div className="absolute left-3 top-3 rounded-md border border-white/10 bg-black/70 px-2 py-1 text-xs text-white">
                              {overlayKey}
                            </div>
                          ) : null}
                          <div className="absolute bottom-3 left-3 max-w-[calc(100%-1.5rem)] rounded-md border border-white/10 bg-black/70 px-2 py-1 text-xs text-white/90">
                            {previewMessage}
                          </div>
                        </div>
                      </div>

                      <div className="rounded-md border border-border/80 bg-background/40 p-3">
                        <div className="mb-2 flex items-center justify-between text-xs text-muted-foreground">
                          <span>{(previewProgress * (selectedSummary?.durationMs || 0) / 1000).toFixed(1)}s</span>
                          <span>Drag to scrub</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="1000"
                          value={Math.round(previewProgress * 1000)}
                          onChange={(event) => {
                            setIsPlaying(false);
                            setPreviewProgress(Number(event.target.value) / 1000);
                          }}
                          className="w-full"
                        />
                      </div>

                      <div className="grid gap-4 lg:grid-cols-[0.8fr_1.2fr]">
                        <Card className="rounded-lg border-border/80 bg-background/30 shadow-none">
                          <CardHeader className="pb-3">
                            <CardTitle className="text-sm">Recorded Input</CardTitle>
                            <CardDescription>Recent keystrokes and the captured viewport.</CardDescription>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            <div className="flex flex-wrap gap-2">
                              {keys.length ? keys.map((key, index) => <Badge key={`${key}-${index}`} variant="secondary" className="rounded-md">{key}</Badge>) : <Badge variant="outline" className="rounded-md">No keystrokes</Badge>}
                            </div>
                            <Separator />
                            <div className="space-y-2 text-sm text-muted-foreground">
                              <div className="flex items-center gap-2">
                                <Monitor className="h-4 w-4" />
                                <span>{viewport.width} × {viewport.height}</span>
                              </div>
                              <p>Device scale factor: {viewport.devicePixelRatio || 1}</p>
                            </div>
                          </CardContent>
                        </Card>

                        <Collapsible open={showActivity} onOpenChange={setShowActivity}>
                          <Card className="rounded-lg border-border/80 bg-background/30 shadow-none">
                            <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
                              <div>
                                <CardTitle className="text-sm">Activity Timeline</CardTitle>
                                <CardDescription>Collapsed by default so the layout stays compact.</CardDescription>
                              </div>
                              <CollapsibleTrigger asChild>
                                <Button variant="ghost" className="rounded-md">
                                  <ChevronDown className={cn("h-4 w-4 transition-transform", showActivity && "rotate-180")} />
                                </Button>
                              </CollapsibleTrigger>
                            </CardHeader>
                            <CollapsibleContent>
                              <CardContent className="space-y-2">
                                {events.map((event, index) => (
                                  <div key={`${event.type}-${event.at}-${index}`} className="rounded-md border border-border/80 bg-background/50 p-3">
                                    <div className="flex items-center justify-between gap-2">
                                      <p className="text-sm font-medium">{event.type.replaceAll("_", " ")}</p>
                                      <p className="text-[11px] text-muted-foreground">{formatDate(event.at)}</p>
                                    </div>
                                    <p className="mt-2 text-xs text-muted-foreground">{labelForEvent(event)}</p>
                                  </div>
                                ))}
                              </CardContent>
                            </CollapsibleContent>
                          </Card>
                        </Collapsible>
                      </div>
                    </CardContent>
                  </>
                )}
              </Card>
            </section>

              </>
            ) : null}

            {activeFolder === "render" ? (
            <section className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
              <Card className="rounded-lg border-border/80 shadow-none">
                <CardHeader className="pb-4">
                  <CardTitle className="text-base">Render</CardTitle>
                  <CardDescription>Render one MP4 per link. Auth is applied before page load if you add a token.</CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4" onSubmit={handleRender}>
                    <div className="rounded-md border border-border/80 bg-background/30 p-3">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <p className="text-sm font-medium">Selected trace</p>
                          <p className="mt-1 text-xs text-muted-foreground">
                            {selectedTrace ? `${selectedTrace.name} · ${selectedSummary ? formatDuration(selectedSummary.durationMs) : "0.0s"}` : "Choose a trace from Recordings first."}
                          </p>
                        </div>
                        <Button type="button" variant="outline" onClick={() => setActiveFolder("recordings")} className="rounded-md">
                          <FolderOpen className="h-4 w-4" />
                          Pick Trace
                        </Button>
                      </div>
                    </div>

                    <div className="rounded-md border border-primary/30 bg-primary/5 p-3">
                      <div className="mb-3 flex items-center gap-2">
	                        <FolderOpen className="h-4 w-4 text-muted-foreground" />
	                        <div>
	                          <p className="text-sm font-medium">1. Export Location</p>
	                          <p className="text-xs text-muted-foreground">Choose a folder once. Files will be named from the CSV company/name column.</p>
	                        </div>
	                      </div>
	                      <div className="grid gap-3 md:grid-cols-[minmax(0,1fr)_180px]">
	                        <div className="space-y-2">
	                          <Label htmlFor="outputDirectory">Selected Folder</Label>
                            <div className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto]">
	                            <Input
	                              id="outputDirectory"
	                              value={outputDirectory}
	                              onChange={(event) => setOutputDirectory(event.target.value)}
	                              placeholder="No folder selected"
	                              className="rounded-md"
	                            />
                              <Button
                                type="button"
                                variant="outline"
                                onClick={chooseOutputDirectory}
                                disabled={isChoosingOutputDirectory}
                                className="rounded-md"
                              >
                                <FolderOpen className="h-4 w-4" />
                                {isChoosingOutputDirectory ? "Opening…" : "Choose Folder"}
                              </Button>
                            </div>
	                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="concurrency">Parallel Videos</Label>
                          <Select value={concurrency} onValueChange={setConcurrency}>
                            <SelectTrigger id="concurrency" className="rounded-md">
                              <SelectValue placeholder="Parallel videos" />
                            </SelectTrigger>
                            <SelectContent>
                              {Array.from({ length: maxRenderConcurrency }, (_, index) => String(index + 1)).map((value) => (
                                <SelectItem key={value} value={value}>{value} at once</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    <div className="grid gap-4 lg:grid-cols-[1fr_1fr]">
                      <div className="space-y-2">
                        <Label>CSV Upload</Label>
                        <button
                          type="button"
                          onClick={() => csvFileRef.current?.click()}
                          onDragOver={(event) => {
                            event.preventDefault();
                            setIsCsvDragActive(true);
                          }}
                          onDragLeave={(event) => {
                            event.preventDefault();
                            setIsCsvDragActive(false);
                          }}
                          onDrop={(event) => {
                            event.preventDefault();
                            setIsCsvDragActive(false);
                            uploadBatchCsv(event.dataTransfer.files?.[0]);
                          }}
                          className={cn(
                            "flex min-h-[120px] w-full flex-col items-center justify-center gap-2 rounded-md border border-dashed px-4 py-5 text-sm transition",
                            isCsvDragActive ? "border-primary bg-accent/60" : "border-border/80 bg-background/30 hover:bg-accent/40"
                          )}
                        >
                          <FileSpreadsheet className="h-5 w-5 text-muted-foreground" />
                          <span>{batchRows.length ? `${batchRows.length} CSV rows loaded` : "Drop a CSV with name + link columns"}</span>
                          <span className="text-xs text-muted-foreground">Columns: Name/Company and Link/URL</span>
                        </button>
                        <input
                          ref={csvFileRef}
                          type="file"
                          accept=".csv,text/csv"
                          className="hidden"
                          onChange={(event) => uploadBatchCsv(event.target.files?.[0])}
                        />
                        <div className="flex flex-wrap items-center gap-2">
                          {batchUploadStatus ? <p className="text-xs text-muted-foreground">{batchUploadStatus}</p> : null}
                          {batchRows.length ? (
                            <Button type="button" variant="ghost" size="sm" onClick={clearBatchRows} className="rounded-md">
                              Clear CSV
                            </Button>
                          ) : null}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="links">Manual Links</Label>
                        <Textarea
                          id="links"
                          value={renderLinks}
                          onChange={(event) => {
                            setBatchRows([]);
                            setRenderLinks(event.target.value);
                          }}
                          placeholder={"Acme Inc, https://example.com/demo/one\nBeta Co, https://example.com/demo/two"}
                          className="min-h-[120px] rounded-md"
                        />
                        <p className="text-xs text-muted-foreground">Use one URL per line, or `Company Name, URL` to name the file.</p>
                      </div>
                    </div>

                    <Collapsible open={showAuthSettings} onOpenChange={setShowAuthSettings}>
                      <div className="rounded-md border border-border/80 bg-background/30">
                        <CollapsibleTrigger asChild>
                          <Button type="button" variant="ghost" className="w-full justify-between rounded-md px-3">
                            <span className="flex items-center gap-2">
                              <Shield className="h-4 w-4" />
                              Auth tokens
                            </span>
                            <ChevronDown className={cn("h-4 w-4 transition-transform", showAuthSettings && "rotate-180")} />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="space-y-4 border-t border-border/80 p-3">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label>Auth Type</Label>
                        <Select value={authType} onValueChange={setAuthType}>
                          <SelectTrigger className="rounded-md">
                            <SelectValue placeholder="Select auth type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">No auth</SelectItem>
                            <SelectItem value="cookie">Cookie token</SelectItem>
                            <SelectItem value="localStorage">Local storage token</SelectItem>
                            <SelectItem value="sessionStorage">Session storage token</SelectItem>
                            <SelectItem value="header">Bearer header</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Auth Items</Label>
                        <div className="rounded-md border border-border/80 bg-background/40 px-3 py-2 text-xs text-muted-foreground">
                          {authType === "header"
                            ? "For header mode, each Key is a header name and each Value is the header value."
                            : "For storage or cookie mode, each Key/Value pair will be injected before replay starts."}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3 rounded-md border border-border/80 bg-background/30 p-3">
                      <div className="grid gap-3 sm:grid-cols-[1fr_auto]">
                        <div className="space-y-2">
                          <Label htmlFor="presetName">Save Token Copy</Label>
                          <Input
                            id="presetName"
                            value={presetName}
                            onChange={(event) => setPresetName(event.target.value)}
                            placeholder="Airaa main account"
                            className="rounded-md"
                          />
                        </div>
                        <div className="flex items-end">
                          <Button type="button" variant="outline" onClick={saveAuthPreset} className="w-full rounded-md sm:w-auto">
                            Save Copy
                          </Button>
                        </div>
                      </div>

                      {authPresets.length ? (
                        <div className="space-y-2">
                          <Label>Saved Copies</Label>
                          <div className="space-y-2">
                            {authPresets.map((preset) => (
                              <div key={preset.id} className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-border/80 bg-background/50 px-3 py-2">
                                <div className="min-w-0">
                                  <p className="truncate text-sm font-medium">{preset.name}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {preset.type} • {preset.entries.length} key{preset.entries.length === 1 ? "" : "s"}
                                  </p>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Button type="button" variant="ghost" onClick={() => loadAuthPreset(preset.id)} className="rounded-md">
                                    Load
                                  </Button>
                                  <Button type="button" variant="ghost" onClick={() => deleteAuthPreset(preset.id)} className="rounded-md">
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : null}
                    </div>

                    {authType !== "none" ? (
                      <div className="space-y-3">
                        {authEntries.map((entry, index) => (
                          <div key={entry.id} className="grid gap-3 rounded-md border border-border/80 bg-background/30 p-3 sm:grid-cols-[1fr_1fr_auto]">
                            <div className="space-y-2">
                              <Label htmlFor={`auth-key-${entry.id}`}>{authType === "header" ? `Header ${index + 1}` : `Key ${index + 1}`}</Label>
                              <Input
                                id={`auth-key-${entry.id}`}
                                value={entry.key}
                                onChange={(event) => updateAuthEntry(entry.id, "key", event.target.value)}
                                placeholder={authType === "header" ? "Authorization" : "airaa-token"}
                                className="rounded-md"
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor={`auth-value-${entry.id}`}>Value {index + 1}</Label>
                              <Input
                                id={`auth-value-${entry.id}`}
                                type="password"
                                value={entry.value}
                                onChange={(event) => updateAuthEntry(entry.id, "value", event.target.value)}
                                placeholder="Paste value"
                                className="rounded-md"
                              />
                            </div>
                            <div className="flex items-end justify-end gap-2">
                              <Button type="button" variant="ghost" onClick={() => removeAuthEntry(entry.id)} className="rounded-md">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                        <Button type="button" variant="outline" onClick={addAuthEntry} className="rounded-md">
                          <Plus className="h-4 w-4" />
                          Add Key
                        </Button>
                      </div>
                    ) : null}
                        </CollapsibleContent>
                      </div>
                    </Collapsible>

                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="speedMultiplier">Speed Multiplier</Label>
                        <Input id="speedMultiplier" type="number" min="0.25" max="4" step="0.25" value={speedMultiplier} onChange={(event) => setSpeedMultiplier(event.target.value)} className="rounded-md" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="startDelaySeconds">Start Delay (seconds)</Label>
                        <Input
                          id="startDelaySeconds"
                          type="number"
                          min="0"
                          max="120"
                          step="1"
                          value={startDelaySeconds}
                          onChange={(event) => setStartDelaySeconds(event.target.value)}
                          className="rounded-md"
                        />
                      </div>
                    </div>

                    <Collapsible open={showAudioSettings} onOpenChange={setShowAudioSettings}>
                      <div className="rounded-md border border-border/80 bg-background/30">
                        <CollapsibleTrigger asChild>
                          <Button type="button" variant="ghost" className="w-full justify-between rounded-md px-3">
                            <span className="flex items-center gap-2">
                              <UploadCloud className="h-4 w-4" />
                              Voice-over
                            </span>
                            <ChevronDown className={cn("h-4 w-4 transition-transform", showAudioSettings && "rotate-180")} />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="space-y-4 border-t border-border/80 p-3">
                    <div className="space-y-2">
                      <Label htmlFor="audioPath">Optional Audio Path</Label>
                      <Input id="audioPath" value={audioPath} onChange={(event) => setAudioPath(event.target.value)} placeholder="/absolute/path/to/audio.mp3" className="rounded-md" />
                    </div>

                    <div className="space-y-2">
                      <Label>Voice-over Upload</Label>
                      <button
                        type="button"
                        onClick={() => audioFileRef.current?.click()}
                        onDragOver={(event) => {
                          event.preventDefault();
                          setIsAudioDragActive(true);
                        }}
                        onDragLeave={(event) => {
                          event.preventDefault();
                          setIsAudioDragActive(false);
                        }}
                        onDrop={(event) => {
                          event.preventDefault();
                          setIsAudioDragActive(false);
                          const file = event.dataTransfer.files?.[0];
                          uploadAudioFile(file);
                        }}
                        className={cn(
                          "flex w-full flex-col items-center justify-center gap-2 rounded-md border border-dashed px-4 py-6 text-sm transition",
                          isAudioDragActive
                            ? "border-primary bg-accent/60"
                            : "border-border/80 bg-background/30 hover:bg-accent/40"
                        )}
                      >
                        <UploadCloud className="h-5 w-5 text-muted-foreground" />
                        <span>{uploadedAudio ? uploadedAudio.originalName : "Drag and drop a voice-over file here"}</span>
                        <span className="text-xs text-muted-foreground">or click to upload</span>
                      </button>
                      <input
                        ref={audioFileRef}
                        type="file"
                        accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg"
                        className="hidden"
                        onChange={(event) => uploadAudioFile(event.target.files?.[0])}
                      />
                      {uploadedAudio ? (
                        <div className="rounded-md border border-border/80 bg-background/30 px-3 py-2 text-xs text-muted-foreground">
                          Using uploaded file: {uploadedAudio.originalName}
                        </div>
                      ) : null}
                      {audioUploadStatus ? <p className="text-xs text-muted-foreground">{audioUploadStatus}</p> : null}
                    </div>
                        </CollapsibleContent>
                      </div>
                    </Collapsible>

                    <div className="rounded-md border border-border/80 bg-background/40 p-3 text-sm text-muted-foreground">
                      <div className="flex items-start gap-2">
                        <Shield className="mt-0.5 h-4 w-4" />
                        <p>Use multiple key/value pairs for `cookie`, `localStorage`, `sessionStorage`, or `header`. Storage auth does an automatic refresh before the replay starts.</p>
                      </div>
                    </div>

                    <Button type="submit" className="w-full rounded-md">
                      <Video className="h-4 w-4" />
                      Render Batch
                    </Button>
                  </form>

                  {renderStatus ? <p className="mt-4 text-xs text-muted-foreground">{renderStatus}</p> : null}
                </CardContent>
              </Card>

              <Card className="rounded-lg border-border/80 shadow-none">
                <CardHeader className="pb-4">
                  <CardTitle className="text-base">Batch Folder</CardTitle>
                  <CardDescription>Keep the page calm: just the selected trace, rows, and output settings.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-3 sm:grid-cols-3 xl:grid-cols-1">
                    <div className="rounded-md border border-border/80 bg-background/40 p-3">
                      <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Rows</p>
                      <p className="mt-2 text-2xl font-semibold">{renderItems.length}</p>
                    </div>
                    <div className="rounded-md border border-border/80 bg-background/40 p-3">
                      <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Parallel</p>
                      <p className="mt-2 text-2xl font-semibold">{concurrency}</p>
                    </div>
                    <div className="rounded-md border border-border/80 bg-background/40 p-3">
                      <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Trace</p>
                      <p className="mt-2 truncate text-sm font-medium">{selectedTrace?.name || "None selected"}</p>
                    </div>
                  </div>

                  <div className="rounded-md border border-border/80 bg-background/40 p-3">
                    <div className="flex items-center gap-2 text-sm font-medium">
                      <FolderOpen className="h-4 w-4 text-muted-foreground" />
                      Export destination
                    </div>
                    <p className="mt-2 break-all font-mono text-xs text-muted-foreground">{outputDirectory || "Default output folder"}</p>
                  </div>

                  <div className="max-h-[360px] space-y-2 overflow-auto pr-1">
                    {renderItems.length ? (
                      renderItems.slice(0, 30).map((item, index) => (
                        <div key={item.id || `${item.link}-${index}`} className="rounded-md border border-border/80 bg-background/40 p-3">
                          <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0">
                              <p className="truncate text-sm font-medium">{item.name || `Video ${index + 1}`}</p>
                              <p className="mt-1 break-all text-xs text-muted-foreground">{item.link}</p>
                            </div>
                            <Badge variant="outline" className="shrink-0 rounded-md">MP4</Badge>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="rounded-md border border-border/80 bg-background/40 p-3 text-sm text-muted-foreground">Upload a CSV or paste manual links to preview the batch.</p>
                    )}
                    {renderItems.length > 30 ? (
                      <p className="text-xs text-muted-foreground">Showing 30 of {renderItems.length} rows.</p>
                    ) : null}
                  </div>

                  <Button type="button" variant="outline" onClick={() => setActiveFolder("jobs")} className="w-full rounded-md">
                    <ListVideo className="h-4 w-4" />
                    Open Jobs & Logs
                  </Button>
                </CardContent>
              </Card>
            </section>
            ) : null}

            {activeFolder === "jobs" ? (
            <section className="grid gap-4">
              <Card className="rounded-lg border-border/80 shadow-none">
                <CardHeader className="flex-row items-start justify-between space-y-0 pb-4">
                  <div>
                    <CardTitle className="text-base">Jobs & Logs</CardTitle>
                    <CardDescription>Outputs stay visible; logs open only from the terminal button.</CardDescription>
                  </div>
                  <Button variant="ghost" size="icon" onClick={loadJobs} className="h-8 w-8 rounded-md">
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </CardHeader>
                <CardContent className="space-y-3">
                  {jobs.length ? (
                    jobs.map((job) => {
                      const logsOpen = Boolean(showLogs[job.id]);
                      const visibleItemStatuses = (job.itemStatuses || [])
                        .filter((item) => item.status !== "queued")
                        .slice(-8);
                      return (
                        <div key={job.id} className="rounded-md border border-border/80 bg-background/40 p-3">
                          <div className="flex flex-wrap items-start justify-between gap-3">
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="text-sm font-medium capitalize">{job.status.replaceAll("_", " ")}</p>
                                <Badge variant={statusVariant(job.status)} className="rounded-md">
                                  {job.linkCount} video{job.linkCount === 1 ? "" : "s"}
                                </Badge>
                                {job.concurrency > 1 ? <Badge variant="outline" className="rounded-md">{job.concurrency} parallel</Badge> : null}
                              </div>
                              <p className="mt-1 text-xs text-muted-foreground">{formatDate(job.updatedAt)}</p>
                              <p className="mt-1 max-w-[720px] break-all text-xs text-muted-foreground">Export: {job.outputDirectory}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              {job.status === "running" || job.status === "queued" || job.status === "resuming" ? (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleJobAction(job.id, "pause")}
                                  className="rounded-md"
                                >
                                  <Pause className="h-4 w-4" />
                                  Pause
                                </Button>
                              ) : null}
                              {job.status === "paused" ? (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleJobAction(job.id, "resume")}
                                  className="rounded-md"
                                >
                                  <Play className="h-4 w-4" />
                                  Resume
                                </Button>
                              ) : null}
                              {!["completed", "completed_with_errors", "failed", "cancelled"].includes(job.status) ? (
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleJobAction(job.id, "cancel")}
                                  disabled={job.status === "canceling"}
                                  className="rounded-md"
                                >
                                  <Trash2 className="h-4 w-4" />
                                  Cancel
                                </Button>
                              ) : null}
                              <Button
                                type="button"
                                variant="ghost"
                                size="icon"
                                onClick={() => setShowLogs((current) => ({ ...current, [job.id]: !current[job.id] }))}
                                className="h-8 w-8 rounded-md"
                              >
                                <Terminal className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>

                          <JobProgress job={job} />

                          {visibleItemStatuses.length ? (
                            <div className="mt-3 grid gap-2 md:grid-cols-2">
                              {visibleItemStatuses.map((item) => (
                                <div key={`${job.id}-${item.index}-${item.link}`} className="rounded-md border border-border/80 bg-background/50 px-3 py-2">
                                  <div className="flex items-center justify-between gap-2">
                                    <p className="truncate text-xs font-medium">{item.name || `Video ${Number(item.index || 0) + 1}`}</p>
                                    <Badge variant={statusVariant(item.status)} className="rounded-md">{item.status}</Badge>
                                  </div>
                                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                                    <div className="h-full bg-primary" style={{ width: `${Math.max(0, Math.min(100, Number(item.progress || 0)))}%` }} />
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : null}

                          {job.error ? <p className="mt-3 rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">{job.error}</p> : null}

                          {job.outputs?.length ? (
                            <div className="mt-3 grid gap-2 lg:grid-cols-2">
                              {job.outputs.map((output, outputIndex) => (
                                <a
                                  key={`${job.id}-${output.outputPath}`}
                                  href={outputHref(job.id, outputIndex)}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="flex items-start gap-2 rounded-md border border-border/80 bg-background/60 px-3 py-2 text-sm hover:bg-accent/60"
                                >
                                  <Download className="mt-0.5 h-4 w-4 text-muted-foreground" />
                                  <div className="min-w-0">
                                    <p className="truncate">{output.name || output.link}</p>
                                    <p className="break-all text-xs text-muted-foreground">{output.outputPath}</p>
                                  </div>
                                </a>
                              ))}
                            </div>
                          ) : (
                            <p className="mt-3 text-xs text-muted-foreground">No output files yet.</p>
                          )}

                          <Collapsible open={logsOpen} onOpenChange={(open) => setShowLogs((current) => ({ ...current, [job.id]: open }))}>
                            <CollapsibleContent>
                              <pre className="mt-3 max-h-64 overflow-auto rounded-md border border-border/80 bg-[#0b0b0c] p-3 text-xs leading-5 text-white/85">
                                {job.logs?.join("\n") || job.error || "No logs for this job yet."}
                              </pre>
                            </CollapsibleContent>
                          </Collapsible>
                        </div>
                      );
                    })
                  ) : (
                    <p className="text-sm text-muted-foreground">No render jobs yet.</p>
                  )}
                </CardContent>
              </Card>
            </section>
            ) : null}
          </div>
        </main>
      </div>
    </div>
  );
}
