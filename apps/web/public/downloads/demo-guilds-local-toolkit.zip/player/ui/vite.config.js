import path from "node:path";
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  root: path.resolve(process.cwd(), "player/ui"),
  build: {
    outDir: path.resolve(process.cwd(), "player/ui/dist"),
    emptyOutDir: true
  },
  resolve: {
    alias: {
      "@": path.resolve(process.cwd(), "player/ui/src")
    }
  }
});
